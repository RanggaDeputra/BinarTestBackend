
viewCustomer($("#customer_id").val());

function viewCustomer(id){

  var data = new FormData();
    data.append('customer_id', id);
    var url = window.location.origin + "/garnis_back_office/customers/get_single_customer";

    $.ajax({
      url: url,
      type: 'POST',
      data: data, 
      processData: false,
      contentType: false,
      dataType: "json",
      beforeSend: function(e) {
        if(e && e.overrideMimeType) {
          e.overrideMimeType("application/json;charset=UTF-8");
        }
      },
      success: function(response){
      
        if(response.status == "success"){ 
          var ttl = response.data.customer_tempat_lahir + ", " + formatDateddmmyyyy(response.data.customer_tgl_lahir);
          var jk = "";
          if (response.data.customer_jk == 1) {
              jk = "Laki-laki";
          }else{
              jk = "Perempuan";
          }
          var status_nikah = "";
          if (response.data.customer_status_nikah == 1) {
              status_nikah = "Kawin";
          }else if (response.data.customer_status_nikah == 2) {
              status_nikah = "Belum Kawin";
          }else if (response.data.customer_status_nikah == 3) {
              status_nikah = "Cerai";
          }

          $("#customer_travel").val(response.data.account_travel_id);
          $("#customer_name").val(response.data.customer_name);
          $("#customer_ttl").val(ttl);
          $("#customer_jk").val(jk);
          $("#customer_kwn").val(response.data.customer_kewarganegaraan);
          $("#customer_pekerjaan").val(response.data.customer_pekerjaan);
          $("#customer_pernikahan").val(status_nikah);
          $("#customer_email").val(response.data.customer_email);
          $("#customer_telepon").val(response.data.customer_telepon);

          $("#customer_passport").val(response.data.passport_number);
          $("#customer_passport_penerbit").val(response.data.passport_issue);

          if (response.data.passport_number != "") {

            $("#customer_passport_tgl_terbit").val(formatDateddmmyyyy(response.data.passport_issue_date));
            $("#customer_passport_masa_berlaku").val(formatDateddmmyyyy(response.data.passport_expire));
          }
          $("#customer_last_tour").val(response.data.customer_negara_akhir_kunjung);
          $("#customer_pimpinan").val(response.data.po_name);
          $("#customer_tour").val(response.data.tour_name);

          if (response.data.tour_sub_category == 2) {
              $("#customer_umroh_view").hide();
              $("#customer_israel_view").show();
          }else if (response.data.tour_sub_category == 1){
              $("#customer_umroh_view").show();
              $("#customer_israel_view").hide();
          }else{
              $("#customer_umroh_view").hide();
              $("#customer_israel_view").hide();
          }

          if (response.data.customer_pernah_israel == 'Y') {
              $("#customer_last_israel").val(formatDateddmmyyyy(response.data.customer_tgl_akhir_israel));
          }

          if (response.data.customer_pernah_umroh == 'Y') {
              $("#customer_last_umroh").val(formatDateddmmyyyy(response.data.customer_tgl_akhir_umroh));
          }

          var visa_status = "On Process";

          if (response.data.vstatus_status == 1) {
              visa_status = "Not Needed";
          }else if (response.data.vstatus_status == 2) {
              visa_status = "Approved";
          }else if (response.data.vstatus_status == 4) {
              visa_status = "Rejected";
          }

          $("#customer_visa").val(visa_status);
          $("#customer_visa_notes").val(response.data.vstatus_note);

          $("#customer_file_passport").attr("src", base_url + "assets/img/dokumen/"+ response.data.customer_file_passport);
          $("#customer_file_ktp").attr("src", base_url + "assets/img/dokumen/"+ response.data.customer_file_ktp);

        }
       },
      error: function (xhr, ajaxOptions, thrownError) { 
        alert(xhr.responseText);
      }
    });
}