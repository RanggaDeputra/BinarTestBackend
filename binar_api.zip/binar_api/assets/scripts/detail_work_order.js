				array_routes =  new Array();
				array_trpts =  new Array();
				array_guide =  new Array();
				array_fnb =  new Array();
				array_hotel =  new Array();
				array_layanan =  new Array();

				count_add_routes = 1;
				count_add_trpts = 1;
				count_add_guide = 1;
				count_add_fnb = 1;
				count_add_hotel = 1;
				count_add_layanan = 1;

				function addDate(date, number){
					var someDate = new Date(date);
					return someDate.setDate(someDate.getDate() + number); 
				}

				function formatDateddmmyyyy(date){
				    var dateObj = new Date(date);
				    var month = dateObj.getMonth() + 1; //months from 1-12
				    var day = dateObj.getDate();
				    var year = dateObj.getFullYear();

				    if (day.toString().length == 1) {
				        day = "0" + day;
				    }

				    if (month.toString().length == 1) {
				        month = "0" + month;
				    }

				    var newdate = day + "-" + month + "-" + year;

				    return newdate;
				}

				viewLandArr($("#wo_id").val());

				function viewLandArr(id){
				    var data = new FormData();
				    data.append('wo_id', id);
				    var url = window.location.origin + "/garnis_back_office/workorder/get_itinerary";

				    $.ajax({
				      url: url, 
				      type: 'POST', 
				      data: data,
				      processData: false,
				      contentType: false,
				      dataType: "json",
				      beforeSend: function(e) {
				        if(e && e.overrideMimeType) {
				          e.overrideMimeType("application/json;charset=UTF-8");
				        }
				      },
				      success: function(response){
				        if(response.status == "success"){
				        	setViewTransport(response.transport);
				        	setViewRoutes(response.routes);
				        	setViewGuide(response.guide);
				        	setViewFnB(response.fnb);
				        	setViewHotel(response.hotel);
				        }
				      },
				      error: function (xhr, ajaxOptions, thrownError) {
				        alert(xhr.responseText);
				      },
				      async: false
				    });
				}

				function setViewRoutes(routes){
					array_routes = routes;

					for(var i = 0; i < array_routes.length; i++){
						var content = '<div class="col-md-12" id="trpts'+array_routes[i].troute_index+'" style="margin-top: 10px;">'+
											'<div class="col-md-1 text-center">'+
												'<span>'+ (i + 1) +'</span>'+
											'</div>'+
											'<div class="col-md-3">'+
												'<span>'+ array_routes[i].route_from_text +'</span>'+
											'</div>'+
											'<div class="col-md-3">'+
												'<span>'+ array_routes[i].route_to_text +'</span>'+
											'</div>'+
											'<div class="col-md-2 text-center">'+
												'<span>'+ formatDateddmmyyyy(array_routes[i].troute_tgl) +'</span>'+
											'</div>'+
											'<div class="col-md-3 text-center">'+
												'<select class="select2" style="width: 100%" id="route_status' + array_routes[i].troute_id +'" onchange="changeStatusRoutes('+array_routes[i].troute_id+');">'+
													'<option value="1">In Proccess</option> '+
													'<option value="2">Ready</option> '+
												'</select>'+
											'</div>'+
											'<div class="col-md-12 lines"></div>'+
										'</div>';

					    $(".container-add-routes").append(content);

					    $("#route_status"+ array_routes[i].troute_id).val(array_routes[i].troute_status_opt);
					    count_add_routes++
					}

				    $("#tour_routes").val(JSON.stringify(array_routes));
				}

				
				function changeStatusRoutes(id){
					for (var i = 0; i < array_routes.length; i++) {
				        if (array_routes[i]['troute_id'] == id) {
				            array_routes[i]['troute_status_opt'] = $("#route_status" + id).val();
				        }
				    }

				    $("#tour_routes").val(JSON.stringify(array_routes));
				}

				function setViewTransport(transport){
					array_trpts = transport;

					for(var i = 0; i < array_trpts.length; i++){
						var content = '<div class="col-md-12" id="trpts'+array_trpts[i].transport_index+'" style="margin-top: 10px;">'+
											'<div class="col-md-1 text-center">'+
												'<span>'+ (i + 1) +'</span>'+
											'</div>'+
											'<div class="col-md-3">'+
												'<span>'+ array_trpts[i].transport_merk +'</span>'+
											'</div>'+
											'<div class="col-md-2 text-center">'+
												'<span>'+ array_trpts[i].transport_tahun +'</span>'+
											'</div>'+
											'<div class="col-md-2 text-center">'+
												'<span>'+ array_trpts[i].transport_kapasitas +'</span>'+
											'</div>'+
											'<div class="col-md-2 text-center">'+
												'<span>'+ formatDateddmmyyyy(addDate(array_trpts[i].tour_tgl_berangkat, parseInt(array_trpts[i].tourdetail_index) - 1)) +'</span>'+
											'</div>'+
											'<div class="col-md-2 text-center">'+
												'<select class="select2" style="width: 100%" id="transpot_status' + array_trpts[i].transport_id +'" onchange="changeStatusTransport('+array_trpts[i].transport_id+');">'+
													'<option value="1">In Proccess</option> '+
													'<option value="2">Ready</option> '+
												'</select>'+
											'</div>'+
											'<div class="col-md-12 lines"></div>'+
										'</div>';

					    $(".container-add-trpts").append(content);

					    $("#transpot_status"+ array_trpts[i].transport_id).val(array_trpts[i].transport_status_opt);
					    count_add_trpts++
					}

				    $("#tour_transport").val(JSON.stringify(array_trpts));
				}

				
				function changeStatusTransport(id){
					for (var i = 0; i < array_trpts.length; i++) {
				        if (array_trpts[i]['transport_id'] == id) {
				            array_trpts[i]['transport_status_opt'] = $("#transpot_status" + id).val();
				        }
				    }

				    $("#tour_transport").val(JSON.stringify(array_trpts));
				}

				function setViewGuide(guide){
					array_guide = guide;

					for(var i = 0; i < array_guide.length; i++){
						var content = '<div class="col-md-12" id="trpts'+array_guide[i].guide_index+'" style="margin-top: 10px;">'+
											'<div class="col-md-1 text-center">'+
												'<span>'+ (i + 1) +'</span>'+
											'</div>'+
											'<div class="col-md-3">'+
												'<span>'+ array_guide[i].guide_nama +'</span>'+
											'</div>'+
											'<div class="col-md-2 text-center">'+
												'<span>'+ formatDateddmmyyyy(addDate(array_guide[i].tour_tgl_berangkat, parseInt(array_guide[i].tourdetail_index) - 1)) +'</span>'+
											'</div>'+
											'<div class="col-md-2 text-center">'+
												'<span>'+ array_guide[i].guide_mulai +'</span>'+
											'</div>'+
											'<div class="col-md-2 text-center">'+
												'<span>'+ array_guide[i].guide_selesai +'</span>'+
											'</div>'+
											'<div class="col-md-2 text-center">'+
												'<select class="select2" style="width: 100%" id="guide_status' + array_guide[i].guide_id +'" onchange="changeStatusGuide('+array_guide[i].guide_id+');">'+
													'<option value="1">In Proccess</option> '+
													'<option value="2">Ready</option> '+
												'</select>'+
											'</div>'+
											'<div class="col-md-12 lines"></div>'+
										'</div>';

					    $(".container-add-guide").append(content);

					    $("#guide_status"+ array_guide[i].guide_id).val(array_guide[i].guide_status_opt);
					    count_add_guide++
					}

				    $("#tour_guide").val(JSON.stringify(array_guide));
				}

				
				function changeStatusGuide(id){
					for (var i = 0; i < array_guide.length; i++) {
				        if (array_guide[i]['guide_id'] == id) {
				            array_guide[i]['guide_status_opt'] = $("#guide_status" + id).val();
				        }
				    }

				    $("#tour_guide").val(JSON.stringify(array_guide));
				}

				function setViewFnB(fnb){
					array_fnb = fnb;

					for(var i = 0; i < array_fnb.length; i++){
						var content = '<div class="col-md-12" id="fnb'+array_fnb[i].fnb_id+'" style="margin-top: 10px;">'+
											'<div class="col-md-1 text-center">'+
												'<span>'+ (i + 1) +'</span>'+
											'</div>'+
											'<div class="col-md-3">'+
												'<span>'+ array_fnb[i].fnb_food +'</span>'+
											'</div>'+
											'<div class="col-md-2 text-center">'+
												'<span>'+ formatDateddmmyyyy(addDate(array_fnb[i].tour_tgl_berangkat, parseInt(array_fnb[i].tourdetail_index) - 1)) +'</span>'+
											'</div>'+
											'<div class="col-md-2">'+
												'<span>'+ array_fnb[i].fnb_disiapkan +'</span>'+
											'</div>'+
											'<div class="col-md-2">'+
												'<span>'+ array_fnb[i].fnb_jenis +'</span>'+
											'</div>'+
											'<div class="col-md-2 text-center">'+
												'<select class="select2" style="width: 100%" id="fnb_status' + array_fnb[i].fnb_id +'" onchange="changeStatusFnB('+array_fnb[i].fnb_id+');">'+
													'<option value="1">In Proccess</option> '+
													'<option value="2">Ready</option> '+
												'</select>'+
											'</div>'+
											'<div class="col-md-12 lines"></div>'+
										'</div>';

					    $(".container-add-fnb").append(content);

					    $("#fnb_status"+ array_fnb[i].fnb_id).val(array_fnb[i].fnb_status_opt);
					    count_add_fnb++
					}

				    $("#tour_fnb").val(JSON.stringify(array_fnb));
				}
				
				function changeStatusFnB(id){
					for (var i = 0; i < array_fnb.length; i++) {
				        if (array_fnb[i]['fnb_id'] == id) {
				            array_fnb[i]['fnb_status_opt'] = $("#fnb_status" + id).val();
				        }
				    }

				    $("#tour_fnb").val(JSON.stringify(array_fnb));
				}

				function setViewHotel(hotel){
					array_hotel = hotel;

					for(var i = 0; i < array_hotel.length; i++){
						var content = '<div class="col-md-12" id="fnb'+array_hotel[i].tourhotel_id+'" style="margin-top: 10px;">'+
											'<div class="col-md-1 text-center">'+
												'<span>'+ (i + 1) +'</span>'+
											'</div>'+
											'<div class="col-md-3">'+
												'<span>'+ array_hotel[i].tourhotel_hotel_name +'</span>'+
											'</div>'+											
											'<div class="col-md-2">'+
												'<span>'+ array_hotel[i].tourhotel_jenis +'</span>'+
											'</div>'+
											'<div class="col-md-2">'+
												'<span>'+ array_hotel[i].tourhotel_fasilitas +'</span>'+
											'</div>'+
											'<div class="col-md-2 text-center">'+
												'<span>'+ formatDateddmmyyyy(addDate(array_hotel[i].tour_tgl_berangkat, parseInt(array_hotel[i].tourdetail_index) - 1)) +'</span>'+
											'</div>'+
											'<div class="col-md-2 text-center">'+
												'<select class="select2" style="width: 100%" id="hotel_status' + array_hotel[i].tourhotel_id +'" onchange="changeStatusHotel('+array_hotel[i].tourhotel_id+');">'+
													'<option value="1">In Proccess</option> '+
													'<option value="2">Ready</option> '+
												'</select>'+
											'</div>'+
											'<div class="col-md-12 lines"></div>'+
										'</div>';

					    $(".container-add-hotel").append(content);

					    $("#hotel_status"+ array_hotel[i].tourhotel_id).val(array_hotel[i].tourhotel_status_opt);
					    count_add_hotel++
					}

				    $("#tour_hotel").val(JSON.stringify(array_hotel));
				}

				
				function changeStatusHotel(id){
					for (var i = 0; i < array_hotel.length; i++) {
				        if (array_hotel[i]['tourhotel_id'] == id) {
				            array_hotel[i]['tourhotel_status_opt'] = $("#hotel_status" + id).val();
				        }
				    }

				    $("#tour_hotel").val(JSON.stringify(array_hotel));
				}

				$("#visa_customer").change(function(){
					var data = new FormData();
				    data.append('customer_id', $(this).val());
				    var url = window.location.origin + "/garnis_back_office/workorder/get_visa_status";

				    $.ajax({
				      url: url, 
				      type: 'POST', 
				      data: data,
				      processData: false,
				      contentType: false,
				      dataType: "json",
				      beforeSend: function(e) {
				        if(e && e.overrideMimeType) {
				          e.overrideMimeType("application/json;charset=UTF-8");
				        }
				      },
				      success: function(response){
				        if(response.status == "success"){
				        	$("#visa_status").val(response.data.vstatus_status).trigger('change');
				        	$("#visa_notes").val(response.data.vstatus_note);
				        }
				      },
				      error: function (xhr, ajaxOptions, thrownError) {
				        alert(xhr.responseText);
				      },
				      async: false
				    });
				});

				$("#visa_customer").trigger('change');

				$("#layanan_customer").change(function(){
					var data = new FormData();
					data.append('wo_id', $("#wo_id").val())
				    data.append('customer_id', $(this).val());
				    var url = window.location.origin + "/garnis_back_office/workorder/get_layanan_customer";

				    $.ajax({
				      url: url, 
				      type: 'POST', 
				      data: data,
				      processData: false,
				      contentType: false,
				      dataType: "json",
				      beforeSend: function(e) {
				        if(e && e.overrideMimeType) {
				          e.overrideMimeType("application/json;charset=UTF-8");
				        }
				      },
				      success: function(response){
				        if(response.status == "success"){
				        	setViewLayanan(response.layanan);
				        }
				      },
				      error: function (xhr, ajaxOptions, thrownError) {
				        alert(xhr.responseText);
				      },
				      async: false
				    });
				});

				$("#layanan_customer").trigger('change');

				function setViewLayanan(layanan){

					$(".container-add-layanan").empty();
					count_add_layanan = 1

					array_layanan = layanan;

					for(var i = 0; i < array_layanan.length; i++){
						var content = '<div class="col-md-12" id="layanan'+array_layanan[i].custlay_id+'" style="margin-top: 10px;">'+
										'<div class="col-md-1 text-center">'+
											'<span>'+ count_add_layanan +'</span>'+
										'</div>'+
										'<div class="col-md-3">'+
											'<span>'+ layanan[i].layanan_name +'</span>'+
										'</div>'+
										'<div class="col-md-2">'+
											'<span>'+ layanan[i].layanan_lokasi +'</span>'+
										'</div>'+
										'<div class="col-md-2 text-center">'+
											'<span>'+ layanan[i].layanan_jam +'</span>'+
										'</div>'+
										'<div class="col-md-2 text-center">'+
											'<span>'+ formatDateddmmyyyy(addDate(array_layanan[i].tour_tgl_berangkat, parseInt(array_layanan[i].tourdetail_index) - 1)) +'</span>'+
										'</div>'+
										'<div class="col-md-2 text-center">'+
												'<select class="select2" style="width: 100%" id="layanan_status' + layanan[i].custlay_id +'" onchange="changeStatusLayanan('+layanan[i].custlay_id+');">'+
													'<option value="1">In Proccess</option> '+
													'<option value="2">Ready</option> '+
												'</select>'+
										'</div>'+
										'<div class="col-md-12 lines"></div>'+
									'</div>';

				    	$(".container-add-layanan").append(content);
				    	$("#layanan_status"+ array_layanan[i].custlay_id).val(array_layanan[i].custlay_status_opt);
					    count_add_layanan++
					}

					$(".select2").select2();
				    $("#tour_layanan").val(JSON.stringify(array_layanan));
				}

				function changeStatusLayanan(id){
					for (var i = 0; i < array_layanan.length; i++) {
				        if (array_layanan[i]['custlay_id'] == id) {
				            array_layanan[i]['custlay_status_opt'] = $("#layanan_status" + id).val();
				        }
				    }

				    $("#tour_layanan").val(JSON.stringify(array_layanan));
				}

				
				$("#wo_status").val($("#status").val());

				$( "#wo_status" ).change(function() {
				  	$("#wo_ubah_status").val($(this).val());
				  	$("#wo_status").val($("#status").val());
				  	$('#modal-finish').modal('show');
				});