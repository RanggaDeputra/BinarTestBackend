$('.nav a[href~="' + location.href + '"]').addClass('active');

		$(".curency").mask("000.000.000.000.000.000", {reverse:true});

		
	   //Timepicker
	    $(".time-picker").timepicker({
	      showInputs: false,
	      showMeridian: false,
	    });

		$("#table-tours").DataTable({
	      	responsive: true,
	      	order: []
	    });

	    $('#table_participant').DataTable({
	      	responsive: true,
	      	order: []
	    });

	    $('#table_user_access').DataTable({
	      	responsive: true,
	      	order: []
	    });

	    $('#table_visa_provider').DataTable({
	      	responsive: true,
	      	order: []
	    });

	    $('#table_hotel').DataTable({
	      	responsive: true,
	      	order: []
	    });

	    $('#table_tourlead').DataTable({
	      	responsive: true,
	      	order: []
	    });

	    $('#table_finance').DataTable({
	      	responsive: true,
	      	order: [],
	    });

	    $('#table_departure').DataTable({
	      	responsive: true,
	      	order: [[ 5, "asc" ]],
	    });

	    $('#table_arrival').DataTable({
	      	responsive: true,
	      	order: [[ 5, "asc" ]],
	    });

	    $(".select2").select2();

	    $('.date-picker').datepicker({
	      autoclose: true
	    });

	    $('#table-pnr').DataTable({
	    	"bFilter": false,
	    	"bPaginate": false,
	      	responsive: true,
	      	order: [[1, "asc"]],
	      	dom: 'Bfrtip',
	        buttons: [
	            {
	                extend: 'excelHtml5',
	                text: 'Export to Excel',
	                title: $(".page-title").text()
	            },
	            {
	                extend: 'csvHtml5',
	                text: 'Export to CSV',
	                title: $(".page-title").text()
	            }
	        ]
	    });

	    $('#table-invoice').DataTable({
	      	responsive: true,
	      	order: [],
	      	dom: 'Bfrtip',
	        buttons: [
	            {
	                extend: 'excelHtml5',
	                text: 'Export to Excel',
	                title: $(".page-title").text(),
	                exportOptions: {
	                    columns: [ 0,1,2,3,4,5,6 ]
	                }
	            },
	            {
	                extend: 'csvHtml5',
	                text: 'Export to CSV',
	                title: $(".page-title").text(),
	                exportOptions: {
	                    columns: [ 0,1,2,3,4,5,6 ]
	                }
	            }
	        ]
	    });

	    $('#table-purchase').DataTable({
	      	responsive: true,
	      	order: [],
	      	dom: 'Bfrtip',
	        buttons: [
	            {
	                extend: 'excelHtml5',
	                text: 'Export to Excel',
	                title: $(".page-title").text(),
	                exportOptions: {
	                    columns: [ 0,1,2,3,4,5 ]
	                }
	            },
	            {
	                extend: 'csvHtml5',
	                text: 'Export to CSV',
	                title: $(".page-title").text(),
	                exportOptions: {
	                    columns: [ 0,1,2,3,4,5 ]
	                }
	            }
	        ]
	    });

	    $('#table-work').DataTable({
	      	responsive: true,
	      	order: [],
	      	dom: 'Bfrtip',
	        buttons: [
	            {
	                extend: 'excelHtml5',
	                text: 'Export to Excel',
	                title: $(".page-title").text(),
	                exportOptions: {
	                    columns: [ 0,1,2,3,4 ]
	                }
	            },
	            {
	                extend: 'csvHtml5',
	                text: 'Export to CSV',
	                title: $(".page-title").text(),
	                exportOptions: {
	                    columns: [ 0,1,2,3,4 ]
	                }
	            }
	        ]
	    });

	    $('#table-reportlist').DataTable({
	      	responsive: true,
	      	order: [],
	      	dom: 'Bfrtip',
	        buttons: [
	            {
	                extend: 'excelHtml5',
	                text: 'Export to Excel',
	                title: $(".page-title").text()
	            },
	            {
	                extend: 'csvHtml5',
	                text: 'Export to CSV',
	                title: $(".page-title").text()
	            }
	        ]
	    });

	    $('#table-invoice-cicilan').DataTable({
	      	responsive: true,
	      	order: []
	    });

	    $('#us3').locationpicker({
			enableAutocomplete: true,
			    enableReverseGeocode: true,
			  radius: 0,
			  inputBinding: {
			    latitudeInput: $('#hotel_latitude'),
			    longitudeInput: $('#hotel_longitude'),
			    radiusInput: $('#hotel_radius'),
			    locationNameInput: $('#hotel_alamat')
			  },
			 
		});
        
        $('#modal-add, #modal-detail').on('shown.bs.modal', function () {
            $('#us3, #us3_detail').locationpicker('autosize');
        });

        $("#pesan-error-password").hide();

        function saveProfile(){
		    if(!$("#user_nopeg").val()){
		        $("#pesan-error").html('ID pegawai wajib diisi!').show();
		        $("#user_nopeg").focus();
		        return false;
		    }else if(!$("#user_name").val()){
		        $("#pesan-error").html('Nama wajib diisi!').show();
		        $("#user_name").focus();
		        return false;
		    }else if(!$("#user_telp").val()){
		        $("#pesan-error").html('Telepon wajib diisi!').show();
		        $("#user_telp").focus();
		        return false;
		    }else if(!$("#user_photo").val()){
		        $("#pesan-error").html('Foto wajib diisi!').show();
		        $("#user_photo").focus();
		        return false;
		    }
		}

		function savePassword(){
		    if(!$("#user_password").val()){
		        $("#pesan-error-password").html('Password wajib diisi!').show();
		        $("#user_password").focus();
		        return false;
		    }else if(!$("#user_password_conf").val()){
		        $("#pesan-error-password").html('Konfirmasi password wajib diisi!').show();
		        $("#user_password_conf").focus();
		        return false;
		    }else if($("#user_password_conf").val() != $("#user_password").val()){
		        $("#pesan-error-password").html('Konfirmasi password tidak sama!').show();
		        $("#user_password_conf").focus();
		        return false;
		    }
		}