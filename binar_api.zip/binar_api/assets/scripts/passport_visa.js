

	$("#passport_customer").change(function(){
		getPassport($(this).val());
	});

	$("#passport_customer").trigger('change');

	$("#passport_required").change(function(){
		if ($(this).val() ==  1) {
			$("#view_passport_required").show();
		}else{
			$("#view_passport_required").hide();
		}
	});

	$("#view_passport_notavailable").hide();
	$("#passport_available").change(function(){
		if ($(this).val() ==  1) {
			$("#view_passport_available").show();
			$("#view_passport_notavailable").hide();
		}else{
			$("#view_passport_notavailable").show();
			$("#view_passport_available").hide();

			$("#passport_no").val('');
			$("#passport_penerbit").val('');
			$("#passport_tgl").val('');
			$("#passport_tgl_akhir").val('')
		}
	});

	$("#passport_put").change(function(){
		if ($(this).val() ==  1) {
			$("#view_passport_put_garnis").show();
		}else{
			$("#view_passport_put_garnis").hide();
		}
	});

	/*$("#visa_customer").change(function(){
		getVisa($(this).val());
	});
	
	$("#visa_customer").trigger('change');*/
	
	$("#visa_required").change(function(){
		if ($(this).val() ==  1) {
			$("#view_visa_required").show();
		}else{
			$("#view_visa_required").hide();
		}
	});

	$("#view_visa_notavailable").hide();
	$("#visa_available").change(function(){
		if ($(this).val() ==  1) {
			$("#view_visa_notavailable").hide();
		}else{
			$("#view_visa_notavailable").show();
			$("#visa_biaya").val('');
		}
	});

	$("#visa_put").change(function(){
		if ($(this).val() ==  1) {
			$("#view_visa_put_garnis").show();
		}else{
			$("#view_visa_put_garnis").hide();
		}
	});

	history.pushState(null, null, location.href);
			      window.onpopstate = function () {
			          history.go(1);
			      };

	function getPassport(id){
		var data = new FormData();
		data.append('customer_id', id);
		var url = window.location.origin + "/garnis_back_office/customers/get_passport";

		$.ajax({
			url: url, 
			type: 'POST', 
			data: data,
			processData: false,
			contentType: false,
			dataType: "json",
			beforeSend: function(e) {
				if(e && e.overrideMimeType) {
				   e.overrideMimeType("application/json;charset=UTF-8");
				}
			},
			success: function(response){

				if(response.status == "success"){ 
					console.log(response.data);

					var passport_required = response.data.passport_required;
				    
				    if (passport_required == null) {
				    	passport_required = 1;
				    }

					$("#passport_required").val(passport_required).trigger('change');

				    var passport_available = response.data.passport_available;
				    
				    if (passport_available == null) {
				    	passport_available = 2;
				    }

				    $("#passport_available").val(passport_available).trigger('change');

				    var passport_put = response.data.passport_put;
				    
				    if (passport_put == null) {
				    	passport_put = 1;
				    }

				    $("#passport_put").val(passport_put).trigger('change');
				    $("#passport_biaya").val(response.data.passport_biaya).trigger('paste');
				    $("#passport_no").val(response.data.passport_number);
				    $("#passport_penerbit").val(response.data.passport_issue);
				    $("#passport_tgl").val(formatDateddmmyyyy(response.data.passport_issue_date));
				    $("#passport_tgl_akhir").val(formatDateddmmyyyy(response.data.passport_expire));

				    var visa_required = response.data.visa_required;
				    
				    if (visa_required == null) {
				    	visa_required = 1;
				    }

				    $("#visa_required").val(visa_required).trigger('change');

				    var visa_available = response.data.visa_available;
				    
				    if (visa_available == null) {
				    	visa_available = 2;
				    }

				    $("#visa_available").val(visa_available).trigger('change');

				    var visa_put = response.data.visa_put;
				    
				    if (visa_put == null) {
				    	visa_put = 1;
				    }
				    $("#visa_put").val(visa_put).trigger('change');
				    $("#visa_biaya").val(response.data.visa_biaya).trigger('paste');

				}else{
					$("#passport_required").val(1).trigger('change');
				    $("#passport_available").val(1).trigger('change');
				    $("#passport_put").val(1).trigger('change');
				    $("#passport_biaya").val(0).trigger('paste');
				    $("#passport_no").val('');
				    $("#passport_penerbit").val('');
				    $("#passport_tgl").val('');
				    $("#passport_tgl_akhir").val('');
				}
			},
			error: function (xhr, ajaxOptions, thrownError) {
				alert(xhr.responseText);
			}
		});
	}

	$('#pesan-error-passport').hide();
	$("#passport_tgl_akhir").change(function(){
					var tgl_berangkat = $("#tgl_berangkat").val();
					var due = addMonth(7, tgl_berangkat);
					var diff = dateDiff(due, $(this).val());
					if (diff < 0) {
						$('#pesan-error-passport').show();
						$(this).focus();
					}else{
						$('#pesan-error-passport').hide();
					}
				});

	/*function getVisa(id){
		var data = new FormData();
		data.append('customer_id', id);
		var url = window.location.origin + "/garnis_back_office/customers/get_visa";

		$.ajax({
			url: url, 
			type: 'POST', 
			data: data,
			processData: false,
			contentType: false,
			dataType: "json",
			beforeSend: function(e) {
				if(e && e.overrideMimeType) {
				   e.overrideMimeType("application/json;charset=UTF-8");
				}
			},
			success: function(response){
				console.log(response);
				if(response.status == "success"){ 
				    $("#visa_required").val(response.data.visa_required).trigger('change');
				    $("#visa_available").val(response.data.visa_available).trigger('change');
				    $("#visa_put").val(response.data.visa_put).trigger('change');
				    $("#visa_biaya").val(response.data.visa_biaya).trigger('paste');
				}else{
					$("#visa_required").val(1).trigger('change');
				    $("#visa_available").val(1).trigger('change');
				    $("#visa_put").val(1).trigger('change');
				    $("#visa_biaya").val(0).trigger('paste');
				}
			},
			error: function (xhr, ajaxOptions, thrownError) {
				alert(xhr.responseText);
			}
		});
	}*/

	function dateDiff(dt1, dt2){
				   	var a = moment(dt1,'DD-MM-YYYY');
					var b = moment(dt2,'DD-MM-YYYY');
					return diffDays = b.diff(a, 'days');
				}

				function addMonth(count, date){
					var dates = moment(date);
					var futureMonth = moment(dates).add(count, 'M');
					var futureMonthEnd = moment(futureMonth).endOf('month');

					if(dates.date() != futureMonth.date() && futureMonth.isSame(futureMonthEnd.format('YYYY-MM-DD'))) {
					    futureMonth = futureMonth.add(count, 'd');
					}

					return futureMonth.format('DD-MM-YYYY');

				}
