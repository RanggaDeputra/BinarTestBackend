				$('#btn-min-rute').hide();
				$('#alert-success, #alert-danger').hide();
				var checked_bts_peserta = false;
				var count_add_rute = 1;

				$("#tour_kategori").change(function(){
				 	var val = $(this).val();
				 	if (val == 1) {
				 		$('#tour_sub_kategori').append($("<option></option>").attr("value", "1").text("Moslem Pilgrimage"));
				 		$('#tour_sub_kategori').append($("<option></option>").attr("value", "2").text("Christian Pilgrimage"));
				 		$("#tour_sub_kategori option[value='3'], #tour_sub_kategori option[value='4']").remove();
				 		/*$('#tour_pemroh').removeAttr('disabled');*/
				 	}else if (val == 2) {
				 		$('#tour_sub_kategori').append($("<option></option>").attr("value", "3").text("Outbound"));
				 		$('#tour_sub_kategori').append($("<option></option>").attr("value", "4").text("Inbound"));
				 		$("#tour_sub_kategori option[value='1'], #tour_sub_kategori option[value='2']").remove();
				 		/*$('#tour_pemroh').attr('disabled','disabled');*/
				 		$('#tour_pemroh').val('0').trigger('change');
				 	}
				});

				function addRoute(){
					if($("#tour_rute_from_1").val() == 0){
				        $("#tour_rute_from_1").focus();
				        return false;
				    }else if(!$("#tour_rute_from_city").val()){
				        $("#tour_rute_from_city").focus();
				        return false;
				    }else if($("#tour_rute_to_1").val() == 0){
				        $("#tour_rute_to_1").focus();
				        return false;
				    }else if(!$("#tour_rute_to_city").val()){
				        $("#tour_rute_to_city").focus();
				        return false;
				    }else if(!$("#tour_rute_tgl_1").val()){
				        $("#tour_rute_tgl_1").focus();
				        return false;
				    }else{
				    	viewRoute();
				    }
				}

				var array_rute = new Array();

				function viewRoute(){

					var rute = new Object();
		            rute['view_id'] = count_add_rute;
		            rute['rute_index'] = count_add_rute;
		            rute['rute_dari'] = $("#tour_rute_from_1").val();
		            rute['rute_dari_kota'] = $("#tour_rute_from_city").val();
		            rute['rute_dari_text'] = $("#tour_rute_from_1 option:selected").text();
		            rute['rute_tujuan'] = $("#tour_rute_to_1").val();
		            rute['rute_tujuan_kota'] = $("#tour_rute_to_city").val();
		            rute['rute_tujuan_text'] = $("#tour_rute_to_1 option:selected").text();
		            rute['rute_tgl'] = $("#tour_rute_tgl_1").val();

		            array_rute.push(rute);

				    var content = '<div class="col-md-12" id="'+count_add_rute+'" style="margin-top: 10px;">'+
										'<div class="col-md-1 text-center">'+
											'<span>'+ rute.rute_index +'</span>'+
										'</div>'+
										'<div class="col-md-4">'+
											'<span>'+ rute.rute_dari_text + ' (' + rute.rute_dari_kota + ')' +'</span>'+
										'</div>'+
										'<div class="col-md-4">'+
											'<span>'+ rute.rute_tujuan_text + ' (' + rute.rute_tujuan_kota + ')' +'</span>'+
										'</div>'+
										'<div class="col-md-3">'+
											'<span>'+ rute.rute_tgl +'</span>'+
										'</div>'+
										'<div class="col-md-12 lines"></div>'+
									'</div>';

				    $(".container-add-rute").append(content);
				    $("#tour_rute_from_1").val('0').trigger('change');
				    $("#tour_rute_to_1").val('0').trigger('change');
				    $("#tour_rute_tgl_1, #tour_rute_from_city, #tour_rute_to_city").val('');
				    count_add_rute++;

				    if (array_rute.length > 0) {
				    	$("#btn-min-rute").show();
				    }

				    console.log(array_rute);
				    setProductSelected();
				}

				function minRoute(){
					count_add_rute--;
					var id = "#" + (count_add_rute);
					$(id).remove();

					array_rute.splice(count_add_rute-1, 1);
					
					if (array_rute.length == 0) {
				    	$("#btn-min-rute").hide();
				    }

				    console.log(array_rute);
				    setProductSelected();
				}

				function setProductSelected(){
				    $("#tour_routes").val(JSON.stringify(array_rute));
				}
				

				function saveTour(){
				    if(!$("#tour_name").val()){
				        $("#pesan-error").html('Nama tour wajib diisi!').show();
				        $("#tour_name").focus();
				        return false;
				    }else if(!$("#tour_tgl_berangkat").val()){
				        $("#pesan-error").html('Tgl berangkat wajib diisi!').show();
				        $("#tour_tgl_berangkat").focus();
				        return false;
				    }else if(!$("#tour_durasi").val()){
				        $("#pesan-error").html('Durasi wajib diisi!').show();
				        $("#tour_durasi").focus();
				        return false;
				    }else if(!$("#tour_biaya").val()){
				        $("#pesan-error").html('Biaya wajib diisi!').show();
				        $("#tour_biaya").focus();
				        return false;
				    }else if($("#tour_tourlead").val() == 0){
				        $("#pesan-error").html('Tour leader wajib dipilih!').show();
				        $("#tour_tourlead").focus();
				        return false;
				    }else if($("#tour_pemroh").val() == 0){
				        $("#pesan-error").html('Pembimbing rohani wajib dipilih!').show();
				        $("#tour_pemroh").focus();
				        return false;
				    }else if($("#tour_vispro").val() == 0){
				        $("#pesan-error").html('Penyedia visa wajib dipilih!').show();
				        $("#tour_vispro").focus();
				        return false;
				    }else if (checked_bts_peserta) {
				        if(!$("#tour_max_peserta").val()){
				            $("#pesan-error").html('Batas jumlah peserta wajib diisi!').show();
				            $("#tour_max_peserta").focus();
				            return false;
				        }
				    }

				    $("#btn-save-tour").attr('disabled','disabled');
				}

				$('#icheck_peserta').on('ifChecked', function (event){
					$('#tour_max_peserta').removeAttr('disabled');
				  checked_bts_peserta = true;
				});

				$('#icheck_peserta').on('ifUnchecked', function (event){
					$('#tour_max_peserta').attr('disabled','disabled');
				  	$('#tour_max_peserta').val('');
				  checked_bts_peserta = false;
				});

				function saveTourLeadInner(){
				    if(!$("#tourlead_name").val()){
				        $("#pesan-error-inner").html('Nama wajib diisi!').show();
				        $("#tourlead_name").focus();
				        return false;
				    }else if(!$("#tourlead_telepon").val()){
				        $("#pesan-error-inner").html('No telepon wajib diisi!').show();
				        $("#tourlead_telepon").focus();
				        return false;
				    }else if(!$("#tourlead_email").val()){
				        $("#pesan-error-inner").html('Email wajib diisi!').show();
				        $("#tourlead_email").focus();
				        return false;
				    }else if(!isValidEmail($("#tourlead_email").val())){
				        $("#pesan-error-inner").html('Email tidak valid!').show();
				        $("#tourlead_email").focus();
				        return false;
				    }else if(!$("#tourlead_photo").val()){
				        $("#pesan-error-inner").html('Foto wajib diisi!').show();
				        $("#tourlead_photo").focus();
				        return false;
				    }else{
				    	var data = new FormData();
					    data.append('tourlead_name', $("#tourlead_name").val());
					    data.append('tourlead_telepon', $("#tourlead_telepon").val());
					    data.append('tourlead_email', $("#tourlead_email").val());
					    data.append('tourlead_photo', $("#tourlead_photo")[0].files[0]);
					    var url = window.location.origin + "/garnis_back_office/tour/save_tourleader";

					    $.ajax({
					      url: url,
					      type: 'POST',
					      data: data, 
					      processData: false,
					      contentType: false,
					      dataType: "json",
					      beforeSend: function(e) {
					        if(e && e.overrideMimeType) {
					          e.overrideMimeType("application/json;charset=UTF-8");
					        }
					      },
					      success: function(response){ 

					      	$("#modal-add-tourlead").modal('hide');

					      	if (response.status == 'success') {
					      		$("#msg-success").html(response.msg);
					      		$("#alert-success").show();

					      		$("#tour_tourlead").empty();
					      		 $("#tour_tourlead").append($("<option></option>")
								     .attr("value", "0").text("Pilih Tour Leader"));
								$.each(response.data, function(key,value) {
								  $("#tour_tourlead").append($("<option></option>")
								     .attr("value", value.tourlead_id).text(value.tourlead_name));
								});

					      	}else{
					      		$("#msg-danger").html(response.msg);
					      		$("#alert-danger").show();
					      	}
					       },
					      error: function (xhr, ajaxOptions, thrownError) { 
					        console.log(xhr);
					      }
					    });
				    }
				}

				function savePemRohInner(){
				    if(!$("#pemroh_name").val()){
				        $("#pesan-error-pemroh").html('Nama wajib diisi!').show();
				        $("#pemroh_name").focus();
				        return false;
				    }else if(!$("#pemroh_telepon").val()){
				        $("#pesan-error-pemroh").html('No telepon wajib diisi!').show();
				        $("#pemroh_telepon").focus();
				        return false;
				    }else if(!$("#pemroh_email").val()){
				        $("#pesan-error-pemroh").html('Email wajib diisi!').show();
				        $("#pemroh_email").focus();
				        return false;
				    }else if(!isValidEmail($("#pemroh_email").val())){
				        $("#pesan-error-pemroh").html('Email tidak valid!').show();
				        $("#pemroh_email").focus();
				        return false;
				    }else if(!$("#pemroh_photo").val()){
				        $("#pesan-error-pemroh").html('Foto wajib diisi!').show();
				        $("#pemroh_photo").focus();
				        return false;
				    }else{
				    	var data = new FormData();
					    data.append('pemroh_name', $("#pemroh_name").val());
					    data.append('pemroh_telepon', $("#pemroh_telepon").val());
					    data.append('pemroh_email', $("#pemroh_email").val());
					    data.append('pemroh_photo', $("#pemroh_photo")[0].files[0]);
					    var url = window.location.origin + "/garnis_back_office/tour/save_pemroh";

					    $.ajax({
					      url: url,
					      type: 'POST',
					      data: data, 
					      processData: false,
					      contentType: false,
					      dataType: "json",
					      beforeSend: function(e) {
					        if(e && e.overrideMimeType) {
					          e.overrideMimeType("application/json;charset=UTF-8");
					        }
					      },
					      success: function(response){ 

					      	$("#modal-add-pemroh").modal('hide');

					      	if (response.status == 'success') {
					      		$("#msg-success").html(response.msg);
					      		$("#alert-success").show();

					      		$("#tour_pemroh").empty();
					      		 $("#tour_pemroh").append($("<option></option>")
								     .attr("value", "0").text("Pilih Pembimbing Rohani"));
								$.each(response.data, function(key,value) {
								  $("#tour_pemroh").append($("<option></option>")
								     .attr("value", value.pemroh_id).text(value.pemroh_name));
								});

					      	}else{
					      		$("#msg-danger").html(response.msg);
					      		$("#alert-danger").show();
					      	}
					       },
					      error: function (xhr, ajaxOptions, thrownError) { 
					        console.log(xhr);
					      }
					    });
				    }
				}


				function saveVProviderInner(){
				    if(!$("#vprovider_name").val()){
				        $("#pesan-error-vispro").html('Nama wajib diisi!').show();
				        $("#vprovider_name").focus();
				        return false;
				    }else if(!$("#vprovider_pic").val()){
				        $("#pesan-error-vispro").html('PIC wajib diisi!').show();
				        $("#vprovider_pic").focus();
				        return false;
				    }else if(!$("#vprovider_email").val()){
				        $("#pesan-error-vispro").html('Email wajib diisi!').show();
				        $("#vprovider_email").focus();
				        return false;
				    }else if(!isValidEmail($("#vprovider_email").val())){
				        $("#pesan-error-vispro").html('Email tidak valid!').show();
				        $("#vprovider_email").focus();
				        return false;
				    }else if(!$("#vprovider_telepon").val()){
				        $("#pesan-error-vispro").html('No telepon wajib diisi!').show();
				        $("#vprovider_telepon").focus();
				        return false;
				    }else{
				    	var data = new FormData();
					    data.append('vprovider_name', $("#vprovider_name").val());
					    data.append('vprovider_pic', $("#vprovider_pic").val());
					    data.append('vprovider_email', $("#vprovider_email").val());
					    data.append('vprovider_telepon', $("#vprovider_telepon").val());
					    var url = window.location.origin + "/garnis_back_office/tour/save_vispro";

					    $.ajax({
					      url: url,
					      type: 'POST',
					      data: data, 
					      processData: false,
					      contentType: false,
					      dataType: "json",
					      beforeSend: function(e) {
					        if(e && e.overrideMimeType) {
					          e.overrideMimeType("application/json;charset=UTF-8");
					        }
					      },
					      success: function(response){ 

					      	$("#modal-add-vispro").modal('hide');

					      	if (response.status == 'success') {
					      		$("#msg-success").html(response.msg);
					      		$("#alert-success").show();

					      		$("#tour_vispro").empty();
					      		 $("#tour_vispro").append($("<option></option>")
								     .attr("value", "0").text("Pilih Penyedia Visa"));
								$.each(response.data, function(key,value) {
								  $("#tour_vispro").append($("<option></option>")
								     .attr("value", value.vprovider_id).text(value.vprovider_name));
								});

					      	}else{
					      		$("#msg-danger").html(response.msg);
					      		$("#alert-danger").show();
					      	}
					       },
					      error: function (xhr, ajaxOptions, thrownError) { 
					        console.log(xhr);
					      }
					    });
				    }
				}
