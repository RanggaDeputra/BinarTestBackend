				var count_add_layanan = 1;
				var array_layanan = new Array();
				$("#btn-min-layanan").hide();

				$("#layanan_name").change(function() {
					var data = new FormData();
				 	data.append('layanan_id', $(this).val());
				    var url = window.location.origin + "/garnis_back_office/customers/get_layanan_harga";

				    $.ajax({
				      url: url, 
				      type: 'POST', 
				      data: data,
				      processData: false,
				      contentType: false,
				      dataType: "json",
				      beforeSend: function(e) {
				        if(e && e.overrideMimeType) {
				          e.overrideMimeType("application/json;charset=UTF-8");
				        }
				      },
				      success: function(response){
				        if(response.status == "success"){ 
				           $("#layanan_biaya").val(response.biaya);
				           $("#layanan_kuota").val(response.kuota);
				        }
				      },
				      error: function (xhr, ajaxOptions, thrownError) {
				        alert(xhr.responseText);
				      }
				    });
				});

				$("#layanan_name").trigger('change');

				function minLayanan(){
					count_add_layanan--;
					var id = "#layanan" + (count_add_layanan);
					$(id).remove();

					array_layanan.splice(count_add_layanan-1, 1);
					
					if (array_layanan.length == 0) {
				    	$("#btn-min-layanan").hide();
				    }

				    $("#layanan").val(JSON.stringify(array_layanan));
				}

				function addLayanan(){
					var layanan = new Object();
		            layanan['custlay_customer_id'] = $("#layanan_customer").val();
		            layanan['custlay_layanan_id'] = $("#layanan_name").val();

		            array_layanan.push(layanan);

				    var content = '<div class="col-md-12" id="layanan'+count_add_layanan+'" style="margin-top: 10px;">'+
										'<div class="col-md-1 text-center">'+
											'<span>'+ count_add_layanan +'</span>'+
										'</div>'+
										'<div class="col-md-4">'+
											'<span>'+ $("#layanan_customer option:selected").text() +'</span>'+
										'</div>'+
										'<div class="col-md-4">'+
											'<span>'+ $("#layanan_name option:selected").text() +'</span>'+
										'</div>'+
										'<div class="col-md-3r">'+
											'<span>'+ $("#layanan_biaya").val() +'</span>'+
										'</div>'+
										'<div class="col-md-12 lines"></div>'+
									'</div>';

				    $(".container-add-layanan").append(content);
				    count_add_layanan++;

				    if (array_layanan.length > 0) {
				    	$("#btn-min-layanan").show();
				    }

				    $("#layanan").val(JSON.stringify(array_layanan));
				}

				history.pushState(null, null, location.href);
			      window.onpopstate = function () {
			          history.go(1);
			      };
