				var checked_bts_peserta = false;
				var count_add_rute = 1;
				var index = 1;
				var durasi = 0;
				var array_detail = new Array();

			  	var count_add_trpts = 1;
			  	var count_add_guide = 1;
			  	var count_add_fnb = 1;
			  	var count_add_hotel = 1;
			  	var count_add_layanan = 1;

				var array_routes = new Array();
				var array_trpts = new Array();
				var array_guide = new Array();
				var array_fnb = new Array();
				var array_hotel = new Array();
				var array_layanan = new Array();

				var array_routes_new = new Array();
				
				$('#btn-min-rute, #btn-min-trpts, #btn-min-guide, #btn-min-fnb, #btn-min-hotel, #btn-min-layanan').hide();
			  	$("#btn-back-detail-tour").hide();

				viewTour($("#tour_id").val());

				$("#tour_kategori").change(function(){
				 	var val = $(this).val();
				 	if (val == 1) {
				 		$('#tour_sub_kategori').append($("<option></option>").attr("value", "1").text("Moslem Pilgrimage"));
				 		$('#tour_sub_kategori').append($("<option></option>").attr("value", "2").text("Christian Pilgrimage"));
				 		$("#tour_sub_kategori option[value='3'], #tour_sub_kategori option[value='4']").remove();
				 		/*$('#tour_pemroh').removeAttr('disabled');*/
				 	}else if (val == 2) {
				 		$('#tour_sub_kategori').append($("<option></option>").attr("value", "3").text("Outbound"));
				 		$('#tour_sub_kategori').append($("<option></option>").attr("value", "4").text("Inbound"));
				 		$("#tour_sub_kategori option[value='1'], #tour_sub_kategori option[value='2']").remove();
				 		/*$('#tour_pemroh').attr('disabled','disabled');*/
				 		$('#tour_pemroh').val('0').trigger('change');
				 	}
				});

				function saveTour(){
				    if(!$("#tour_name").val()){
				        $("#pesan-error").html('Nama tour wajib diisi!').show();
				        $("#tour_name").focus();
				        return false;
				    }else if(!$("#tour_durasi").val()){
				        $("#pesan-error").html('Durasi wajib diisi!').show();
				        $("#tour_durasi").focus();
				        return false;
				    }else if(!$("#tour_biaya").val()){
				        $("#pesan-error").html('Biaya wajib diisi!').show();
				        $("#tour_biaya").focus();
				        return false;
				    }else if(!$("#tour_tgl_berangkat").val()){
				        $("#pesan-error").html('Tgl berangkat wajib diisi!').show();
				        $("#tour_tgl_berangkat").focus();
				        return false;
				    }else if($("#tour_tourlead").val() == 0){
				        $("#pesan-error").html('Tour leader wajib dipilih!').show();
				        $("#tour_tourlead").focus();
				        return false;
				    }else if($("#tour_pemroh").val() == 0){
				        $("#pesan-error").html('Pembimbing rohani wajib dipilih!').show();
				        $("#tour_pemroh").focus();
				        return false;
				    }else if($("#tour_vispro").val() == 0){
				        $("#pesan-error").html('Penyedia visa wajib dipilih!').show();
				        $("#tour_vispro").focus();
				        return false;
				    }else if (checked_bts_peserta) {
				        if(!$("#tour_max_peserta").val()){
				            $("#pesan-error").html('Batas jumlah peserta wajib diisi!').show();
				            $("#tour_max_peserta").focus();
				            return false;
				        }
				    }

				    $("#btn-save-tour").attr('disabled','disabled');
				}

				$('#icheck_peserta').on('ifChecked', function (event){
					$('#tour_max_peserta').removeAttr('disabled');
				  checked_bts_peserta = true;
				});

				$('#icheck_peserta').on('ifUnchecked', function (event){
					$('#tour_max_peserta').attr('disabled','disabled');
				  	$('#tour_max_peserta').val('');
				  checked_bts_peserta = false;
				});

				function viewTour(id){
				    var data = new FormData();
				    data.append('tour_id', id);
				    var url = window.location.origin + "/garnis_back_office/tour/get_single";

				    $.ajax({
				      url: url, 
				      type: 'POST', 
				      data: data,
				      processData: false,
				      contentType: false,
				      dataType: "json",
				      beforeSend: function(e) {
				        if(e && e.overrideMimeType) {
				          e.overrideMimeType("application/json;charset=UTF-8");
				        }
				      },
				      success: function(response){
				        if(response.status == "success"){ 
				           $("#page-title").html(response.tour.tour_code + " - " + response.tour.tour_name);

				           	if (response.tour.tour_category == 2) {
				           		$("#tour_sub_kategori option[value='1'], #tour_sub_kategori option[value='2'], #tour_sub_kategori option[value='3'], #tour_sub_kategori option[value='4']").remove();
						 		$('#tour_sub_kategori').append($("<option></option>").attr("value", "3").text("Outbound"));
						 		$('#tour_sub_kategori').append($("<option></option>").attr("value", "4").text("Inbound"));
						 		/*$('#tour_pemroh').attr('disabled','disabled');*/
						 		$('#tour_pemroh').val('0').trigger('change');
						 	}

				           $("#tour_kategori").val(response.tour.tour_category).trigger('change');
				           $("#tour_sub_kategori").val(response.tour.tour_sub_category).trigger('change');
				           $("#tour_name").val(response.tour.tour_name);
				           $("#tour_code, #tour_code_u").val(response.tour.tour_code);
				           $("#tour_durasi").val(response.tour.tour_durasi);
				           $("#tour_biaya").val(response.tour.tour_biaya).trigger('paste');
				           $("#tour_tgl_berangkat").val(formatDateddmmyyyy(response.tour.tour_tgl_berangkat)).trigger('change');

				           if (response.tour.tour_batas_peserta != null) {
				              $("#tour_max_peserta").val(response.tour.tour_batas_peserta);
				              $("#tour_max_peserta").removeAttr('disabled');
				              $("#icheck_peserta").iCheck('check');
				              checked_bts_peserta = true;
				           }

				           $("#tour_status").val(response.tour.tour_status).trigger('change');
				           $("#tour_tourlead").val(response.tour.tour_tourlead_id).trigger('change');
				           $("#tour_pemroh").val(response.tour.tour_pemroh_id).trigger('change');
				           $("#tour_vispro").val(response.tour.tour_vprovider_id).trigger('change');
				           $("#data_detail_tour").val(JSON.stringify(response.tour_detail));
				           $("#tgl_maks_pesan").html(minusDate(response.tour.tour_tgl_berangkat, 60));

				           setViewRoutes(response.tour_routes);

						    durasi = response.tour.tour_durasi;

				           	$("#number_itinerary").html(index + "/" + durasi);

				            for(var i = 0; i < response.tour.tour_durasi; i++){
								var detail = new Object();
								detail['tourdetail_index'] = "";
								detail['tourdetail_tour_id'] = "";
								detail['tourdetail_title'] = "";
								detail['tourdetail_kegiatan'] = "";
								array_detail.push(detail);
							}
				            
				           	if (response.tour_detail.length > 0) {
								setTourDetail(response.tour_detail);
				           	}
				        }
				      },
				      error: function (xhr, ajaxOptions, thrownError) {
				        alert(xhr.responseText);
				      },
				      async: false
				    });

				}

				function setViewRoutes(routes){
					array_routes = routes;

					for(var i = 0; i < array_routes.length; i++){
						var content = '<div class="col-md-12" id="trpts'+array_routes[i].troute_index+'" style="margin-top: 10px;">'+
											'<div class="col-md-1 text-center">'+
												'<span>'+ (i + 1) +'</span>'+
											'</div>'+
											'<div class="col-md-3">'+
												'<span>'+ array_routes[i].route_from_text + ' (' +  array_routes[i].troute_from_city + ')' +'</span>'+
											'</div>'+
											'<div class="col-md-3">'+
												'<span>'+ array_routes[i].route_to_text + ' (' +  array_routes[i].troute_to_city + ')' +'</span>'+
											'</div>'+
											'<div class="col-md-2 text-center">'+
												'<span>'+ formatDateddmmyyyy(array_routes[i].troute_tgl) +'</span>'+
											'</div>'+
											'<div class="col-md-3 text-center">'+
												'<select class="select2" style="width: 100%" id="route_status' + array_routes[i].troute_id +'" onchange="changeStatusRoutes('+array_routes[i].troute_id+');">'+
													'<option value="1">Active</option> '+
													'<option value="3">Cancel</option> '+
												'</select>'+
											'</div>'+
											'<div class="col-md-12 lines"></div>'+
										'</div>';

					    $(".container-add-rute").append(content);

					    $("#route_status"+ array_routes[i].troute_id).val(array_routes[i].troute_status);
					    count_add_rute++
					}

				    $("#tour_routes").val(JSON.stringify(array_routes));
				}


				function changeStatusRoutes(id){
					for (var i = 0; i < array_routes.length; i++) {
				        if (array_routes[i]['troute_id'] == id) {
				            array_routes[i]['troute_status'] = $("#route_status" + id).val();
				        }
				    }

				    $("#tour_routes").val(JSON.stringify(array_routes));
				}

				function addRoute(){
					if($("#tour_rute_from_1").val() == 0){
				        $("#tour_rute_from_1").focus();
				        return false;
				    }else if(!$("#tour_rute_from_city").val()){
				        $("#tour_rute_from_city").focus();
				        return false;
				    }else if($("#tour_rute_to_1").val() == 0){
				        $("#tour_rute_to_1").focus();
				        return false;
				    }else if(!$("#tour_rute_to_city").val()){
				        $("#tour_rute_to_city").focus();
				        return false;
				    }else if(!$("#tour_rute_tgl_1").val()){
				        $("#tour_rute_tgl_1").focus();
				        return false;
				    }else{
				    	viewRoute();
				    }
				}

				function viewRoute(){
					var rute = new Object();
		            rute['troute_index'] = count_add_rute;
		            rute['troute_from'] = $("#tour_rute_from_1").val();
		            rute['troute_from_city'] = $("#tour_rute_from_city").val();
		            rute['troute_to'] = $("#tour_rute_to_1").val();
		            rute['troute_to_city'] = $("#tour_rute_to_city").val();
		            rute['troute_tgl'] = $("#tour_rute_tgl_1").val();
		            rute['troute_tour_id'] = $("#tour_id").val();

		            array_routes_new.push(rute);

		            var content = '<div class="col-md-12" id="trpts'+count_add_rute+'" style="margin-top: 10px;">'+
											'<div class="col-md-1 text-center">'+
												'<span>'+ count_add_rute +'</span>'+
											'</div>'+
											'<div class="col-md-3">'+
												'<span>'+  $("#tour_rute_from_1 option:selected").text() + ' (' + rute.troute_from_city + ')' +'</span>'+
											'</div>'+
											'<div class="col-md-3">'+
												'<span>'+ $("#tour_rute_to_1 option:selected").text() + ' (' + rute.troute_to_city + ')' +'</span>'+
											'</div>'+
											'<div class="col-md-2 text-center">'+
												'<span>'+ $("#tour_rute_tgl_1").val() +'</span>'+
											'</div>'+
											'<div class="col-md-3 text-center">'+
												
											'</div>'+
											'<div class="col-md-12 lines"></div>'+
										'</div>';

				    $(".container-add-rute").append(content);
				    $("#tour_rute_from_1").val('0').trigger('change');
				    $("#tour_rute_to_1").val('0').trigger('change');
				    $("#tour_rute_tgl_1, #tour_rute_from_city, #tour_rute_to_city").val('');
				    count_add_rute++;

				    $("#tour_routes_new").val(JSON.stringify(array_routes_new));
				}				

				function setTourDetail(detail){
					$("#tour_id").val(detail[0].tourdetail_tour_id);
					$("#tour_title").val(detail[0].tourdetail_title);
					$("#tour_kegiatan").val(detail[0].tourdetail_kegiatan);

					for(var i = 0; i < detail.length; i++){
						array_detail[i].tourdetail_id = detail[i].tourdetail_id;
						array_detail[i].tourdetail_index = detail[i].tourdetail_index;
						array_detail[i].tourdetail_tour_id = detail[i].tourdetail_tour_id;
						array_detail[i].tourdetail_title = detail[i].tourdetail_title;
						array_detail[i].tourdetail_kegiatan = detail[i].tourdetail_kegiatan;
					}
				}

				function save() {
					if (index < durasi) {

						if (saveDetailTour()) {
							$("#index-detail-tour").html("Hari ke - " + (index + 1));
							$("#number_itinerary").html((index + 1) + "/" + durasi);

							if (index >= 1) {
								$("#btn-back-detail-tour").show();
								$("#btn-next-detail-tour").html('Selanjutnya <span class="glyphicon glyphicon-chevron-right"></span>');
							}

							var count =  index - 1;

							array_detail[count].tourdetail_index = index;
							array_detail[count].tourdetail_tour_id = $("#tour_id").val();
							array_detail[count].tourdetail_title = $("#tour_title").val();
							array_detail[count].tourdetail_kegiatan = $("#tour_kegiatan").val();

							index++;

							if(durasi == index){
								$("#btn-next-detail-tour").html('<span class="glyphicon glyphicon-ok"></span> Selesai');
							}

							setValueDetail(array_detail[index - 1]);
						}

					}else if(index == durasi){
						if (saveDetailTour()) {
							var count =  index - 1;
							array_detail[count].tourdetail_index = index;
							array_detail[count].tourdetail_tour_id = $("#tour_id").val();
							array_detail[count].tourdetail_title = $("#tour_title").val();
							array_detail[count].tourdetail_kegiatan = $("#tour_kegiatan").val();

							$('#data_detail_tour').val(JSON.stringify(array_detail));
							$('#modal-finish').modal('show');
						}
					}

					console.log(array_detail);

				}

				function edit() {
					if (index <= durasi) {

						$("#index-detail-tour").html("Hari ke - " + (index - 1));
						$("#number_itinerary").html((index - 1) + "/" + durasi);

						var count =  index - 1;
						array_detail[count].tourdetail_index = index;
						array_detail[count].tourdetail_tour_id = $("#tour_id").val();
						array_detail[count].tourdetail_title = $("#tour_title").val();
						array_detail[count].tourdetail_kegiatan = $("#tour_kegiatan").val();


						if (index >= 1) {
							$("#btn-back-detail-tour").show();
							$("#btn-next-detail-tour").html('Selanjutnya <span class="glyphicon glyphicon-chevron-right"></span>');
						}

						index--;

						if(index == 1){
							$("#btn-back-detail-tour").hide();
							$("#btn-back-to-tour").show();
						}

						setValueDetail(array_detail[index - 1]);
					}

					console.log(array_detail);
				}

				function saveDetailTour(){
				    if(!$("#tour_title").val()){
				        $("#pesan-error-detail").html('Judul itinerary wajib diisi!').show();
				        $("#tour_title").focus();
				        return false;
				    }else if(!$("#tour_kegiatan").val()){
				        $("#pesan-error-detail").html('Kegiatan itinerary wajib diisi!').show();
				        $("#tour_kegiatan").focus();
				        return false;
				    }else{
				    	$("#pesan-error-detail").hide();
				    	return true;
				    }
				}

				function setValueDetail(obj){
					$("#tour_title").val(obj.tourdetail_title);
					$("#tour_kegiatan").val(obj.tourdetail_kegiatan);
				}

				$("#tourdetail_id").change(function(){
					$(".container-add-trpts, .container-add-guide, .container-add-fnb, .container-add-hotel, .container-add-layanan").empty();
					$('#btn-min-trpts, #btn-min-guide, #btn-min-fnb, #btn-min-hotel, #btn-min-layanan').hide();

					array_trpts =  new Array();
					array_guide =  new Array();
					array_fnb =  new Array();
					array_hotel =  new Array();
					array_layanan =  new Array();

					array_trpts_new =  new Array();
					array_guide_new =  new Array();
					array_fnb_new =  new Array();
					array_hotel_new = new Array();
					array_layanan_new = new Array();

					count_add_trpts = 1;
					count_add_guide = 1;
					count_add_fnb = 1;
					count_add_hotel = 1;
					count_add_layanan = 1;

					viewLandArr($(this).val());
				});

				$("#tourdetail_id").trigger('change');

				function viewLandArr(id){
				    var data = new FormData();
				    data.append('detail_id', id);
				    var url = window.location.origin + "/garnis_back_office/tour/get_single_detail";

				    $.ajax({
				      url: url, 
				      type: 'POST', 
				      data: data,
				      processData: false,
				      contentType: false,
				      dataType: "json",
				      beforeSend: function(e) {
				        if(e && e.overrideMimeType) {
				          e.overrideMimeType("application/json;charset=UTF-8");
				        }
				      },
				      success: function(response){
				        if(response.status == "success"){
				        	setViewTransport(response.transport);
				        	setViewGuide(response.guide);
				        	setViewFnB(response.fnb);
				        	setViewHotel(response.hotel);
				        	setViewLayanan(response.layanan);
				        }
				      },
				      error: function (xhr, ajaxOptions, thrownError) {
				        alert(xhr.responseText);
				      },
				      async: false
				    });
				}

				function addTransport(){
					if(!$("#merk_kendaraan_1").val()){
				        $("#merk_kendaraan_1").focus();
				        return false;
				    }else if(!$("#thn_kendaraan_1").val()){
				        $("#thn_kendaraan_1").focus();
				        return false;
				    }else if(!$("#kapasitas_kendaraan_1").val()){
				        $("#kapasitas_kendaraan_1").focus();
				        return false;
				    }else{
				    	viewTransport();
				    }
				}

				function viewTransport(){
					var trpts = new Object();
		            trpts['transport_index'] = count_add_trpts;
		            trpts['transport_merk'] = $("#merk_kendaraan_1").val();
		            trpts['transport_tahun'] = $("#thn_kendaraan_1").val();
		            trpts['transport_kapasitas'] = $("#kapasitas_kendaraan_1").val();
		            trpts['transport_tourdetail_id'] = $("#tourdetail_id").val();

		            array_trpts_new.push(trpts);

				    var content = '<div class="col-md-12" id="trpts'+count_add_trpts+'" style="margin-top: 10px;">'+
										'<div class="col-md-1 text-center">'+
											'<span>'+ trpts.transport_index +'</span>'+
										'</div>'+
										'<div class="col-md-3">'+
											'<span>'+ trpts.transport_merk +'</span>'+
										'</div>'+
										'<div class="col-md-3 text-center">'+
											'<span>'+ trpts.transport_tahun +'</span>'+
										'</div>'+
										'<div class="col-md-3 text-center">'+
											'<span>'+ trpts.transport_kapasitas +'</span>'+
										'</div>'+
										'<div class="col-md-2">'+
											
										'</div>'+
										'<div class="col-md-12 lines"></div>'+
									'</div>';

				    $(".container-add-trpts").append(content);
				    count_add_trpts++;

				    $("#merk_kendaraan_1, #thn_kendaraan_1, #kapasitas_kendaraan_1").val('');
				    $("#tour_transport_new").val(JSON.stringify(array_trpts_new));
				}

				function setViewTransport(transport){
					array_trpts = transport;

					for(var i = 0; i < array_trpts.length; i++){
							var content = '<div class="col-md-12" id="trpts'+array_trpts[i].transport_index+'" style="margin-top: 10px;">'+
											'<div class="col-md-1 text-center">'+
												'<span>'+ (i + 1) +'</span>'+
											'</div>'+
											'<div class="col-md-3">'+
												'<span>'+ array_trpts[i].transport_merk +'</span>'+
											'</div>'+
											'<div class="col-md-3 text-center">'+
												'<span>'+ array_trpts[i].transport_tahun +'</span>'+
											'</div>'+
											'<div class="col-md-3 text-center">'+
												'<span>'+ array_trpts[i].transport_kapasitas +'</span>'+
											'</div>'+
											'<div class="col-md-2 text-center">'+
												'<select class="select2" style="width: 100%" id="transpot_status' + array_trpts[i].transport_id +'" onchange="changeStatusTransport('+array_trpts[i].transport_id+');">'+
													'<option value="1">Active</option> '+
													'<option value="3">Cancel</option> '+
												'</select>'+
											'</div>'+
											'<div class="col-md-12 lines"></div>'+
										'</div>';

					    $(".container-add-trpts").append(content);

					    $("#transpot_status"+ array_trpts[i].transport_id).val(array_trpts[i].transport_status);
					    count_add_trpts++
					}

					$(".select2").select2();

				    $("#tour_transport").val(JSON.stringify(array_trpts));
				}

				function changeStatusTransport(id){
					for (var i = 0; i < array_trpts.length; i++) {
				        if (array_trpts[i]['transport_id'] == id) {
				            array_trpts[i]['transport_status'] = $("#transpot_status" + id).val();
				        }
				    }

				    $("#tour_transport").val(JSON.stringify(array_trpts));
				}

				function addGuide(){
					if(!$("#tourguide_nama").val()){
				        $("#tourguide_nama").focus();
				        return false;
				    }else if(!$("#tourguide_mulai").val()){
				        $("#tourguide_mulai").focus();
				        return false;
				    }else if(!$("#tourguide_selesai").val()){
				        $("#tourguide_selesai").focus();
				        return false;
				    }else{
				    	viewGuide();
				    }
				}

				function viewGuide(){
					var guide = new Object();
		            guide['guide_index'] = count_add_guide;
		            guide['guide_nama'] = $("#tourguide_nama").val();
		            guide['guide_mulai'] = $("#tourguide_mulai").val();
		            guide['guide_selesai'] = $("#tourguide_selesai").val();
		            guide['guide_tourdetail_id'] = $("#tourdetail_id").val();

		            array_guide_new.push(guide);

				    var content = '<div class="col-md-12" id="guide'+count_add_guide+'" style="margin-top: 10px;">'+
										'<div class="col-md-1 text-center">'+
											'<span>'+ guide.guide_index +'</span>'+
										'</div>'+
										'<div class="col-md-3">'+
											'<span>'+ guide.guide_nama +'</span>'+
										'</div>'+
										'<div class="col-md-3 text-center">'+
											'<span>'+ guide.guide_mulai +'</span>'+
										'</div>'+
										'<div class="col-md-3 text-center">'+
											'<span>'+ guide.guide_selesai +'</span>'+
										'</div>'+
										'<div class="col-md-2 text-center">'+
											
										'</div>'+
										'<div class="col-md-12 lines"></div>'+
									'</div>';

				    $(".container-add-guide").append(content);
				    count_add_guide++;

				    $("#tourguide_nama").val('');
				    $("#tour_guide_new").val(JSON.stringify(array_guide_new));
				}

				function setViewGuide(guide){
					array_guide = guide;

					for(var i = 0; i < array_guide.length; i++){
						var content = '<div class="col-md-12" id="trpts'+array_guide[i].guide_index+'" style="margin-top: 10px;">'+
											'<div class="col-md-1 text-center">'+
												'<span>'+ (i + 1) +'</span>'+
											'</div>'+
											'<div class="col-md-3">'+
												'<span>'+ array_guide[i].guide_nama +'</span>'+
											'</div>'+
											'<div class="col-md-3 text-center">'+
												'<span>'+ array_guide[i].guide_mulai +'</span>'+
											'</div>'+
											'<div class="col-md-3 text-center">'+
												'<span>'+ array_guide[i].guide_selesai +'</span>'+
											'</div>'+
											'<div class="col-md-2 text-center">'+
												'<select class="select2" style="width: 100%" id="guide_status' + array_guide[i].guide_id +'" onchange="changeStatusGuide('+array_guide[i].guide_id+');">'+
													'<option value="1">Active</option> '+
													'<option value="3">Cancel</option> '+
												'</select>'+
											'</div>'+
											'<div class="col-md-12 lines"></div>'+
										'</div>';

					    $(".container-add-guide").append(content);

					    $("#guide_status"+ array_guide[i].guide_id).val(array_guide[i].guide_status);
					    count_add_guide++
					}
				    
				    $(".select2").select2();

				    $("#tour_guide").val(JSON.stringify(array_guide));
				}

				function changeStatusGuide(id){
					for (var i = 0; i < array_guide.length; i++) {
				        if (array_guide[i]['guide_id'] == id) {
				            array_guide[i]['guide_status'] = $("#guide_status" + id).val();
				        }
				    }

				    $("#tour_guide").val(JSON.stringify(array_guide));
				}

				function addFnB(){
					if(!$("#food_fb").val()){
				        $("#food_fb").focus();
				        return false;
				    }else if(!$("#food_disiapkan").val()){
				        $("#food_disiapkan").focus();
				        return false;
				    }else if(!$("#food_jenis").val()){
				        $("#food_jenis").focus();
				        return false;
				    }else{
				    	viewFnB();
				    }
				}

				function viewFnB(){
					var fnb = new Object();
		            fnb['fnb_index'] = count_add_fnb;
		            fnb['fnb_food'] = $("#food_fb").val();
		            fnb['fnb_disiapkan'] = $("#food_disiapkan").val();
		            fnb['fnb_jenis'] = $("#food_jenis").val();
		            fnb['fnb_tourdetail_id'] = $("#tourdetail_id").val();

		            array_fnb_new.push(fnb);

				    var content = '<div class="col-md-12" id="fnb'+count_add_fnb+'" style="margin-top: 10px;">'+
										'<div class="col-md-1 text-center">'+
											'<span>'+ fnb.fnb_index +'</span>'+
										'</div>'+
										'<div class="col-md-3">'+
											'<span>'+ fnb.fnb_food +'</span>'+
										'</div>'+
										'<div class="col-md-3">'+
											'<span>'+ fnb.fnb_disiapkan +'</span>'+
										'</div>'+
										'<div class="col-md-3">'+
											'<span>'+ fnb.fnb_jenis +'</span>'+
										'</div>'+
										'<div class="col-md-2">'+
										'</div>'+
										'<div class="col-md-12 lines"></div>'+
									'</div>';

				    $(".container-add-fnb").append(content);
				    count_add_fnb++;

				    $("#food_fb, #food_disiapkan, #food_jenis").val('');
				    $("#tour_food_new").val(JSON.stringify(array_fnb_new));
				}

				function setViewFnB(fnb){
					array_fnb = fnb;

					for(var i = 0; i < array_fnb.length; i++){
						var content = '<div class="col-md-12" id="fnb'+array_fnb[i].fnb_id+'" style="margin-top: 10px;">'+
											'<div class="col-md-1 text-center">'+
												'<span>'+ (i + 1) +'</span>'+
											'</div>'+
											'<div class="col-md-3">'+
												'<span>'+ array_fnb[i].fnb_food +'</span>'+
											'</div>'+
											'<div class="col-md-3">'+
												'<span>'+ array_fnb[i].fnb_disiapkan +'</span>'+
											'</div>'+
											'<div class="col-md-3">'+
												'<span>'+ array_fnb[i].fnb_jenis +'</span>'+
											'</div>'+
											'<div class="col-md-2 text-center">'+
												'<select class="select2" style="width: 100%" id="fnb_status' + array_fnb[i].fnb_id +'" onchange="changeStatusFnB('+array_fnb[i].fnb_id+');">'+
													'<option value="1">Active</option> '+
													'<option value="3">Cancel</option> '+
												'</select>'+
											'</div>'+
											'<div class="col-md-12 lines"></div>'+
										'</div>';

					    $(".container-add-fnb").append(content);
					     $("#fnb_status"+ array_fnb[i].fnb_id).val(array_fnb[i].fnb_status);
					    count_add_fnb++
					}

					$(".select2").select2();
				    $("#tour_food").val(JSON.stringify(array_fnb));
				}

				function changeStatusFnB(id){
					for (var i = 0; i < array_fnb.length; i++) {
				        if (array_fnb[i]['fnb_id'] == id) {
				            array_fnb[i]['fnb_status'] = $("#fnb_status" + id).val();
				        }
				    }

				    $("#tour_food").val(JSON.stringify(array_fnb));
				}

				function addHotel(){
					if($("#hotel_name").val() == 0){
				        $("#hotel_name").focus();
				        return false;
				    }else if(!$("#hotel_jenis").val()){
				        $("#hotel_jenis").focus();
				        return false;
				    }else if(!$("#hotel_fasilitas").val()){
				        $("#hotel_fasilitas").focus();
				        return false;
				    }else{
				    	viewHotel();
				    }
				}

				function viewHotel(){
					var hotel = new Object();
		            hotel['tourhotel_index'] = count_add_hotel;
		            hotel['tourhotel_hotel_name'] = $("#hotel_name option:selected").text();
		            hotel['tourhotel_jenis'] = $("#hotel_jenis").val();
		            hotel['tourhotel_fasilitas'] = $("#hotel_fasilitas").val();
		            hotel['tourhotel_tourdetail_id'] = $("#tourdetail_id").val();

		            array_hotel_new.push(hotel);

				    var content = '<div class="col-md-12" id="hotel'+count_add_hotel+'" style="margin-top: 10px;">'+
										'<div class="col-md-1 text-center">'+
											'<span>'+ hotel.tourhotel_index +'</span>'+
										'</div>'+
										'<div class="col-md-3">'+
											'<span>'+ $("#hotel_name option:selected").text() +'</span>'+
										'</div>'+
										'<div class="col-md-3">'+
											'<span>'+ hotel.tourhotel_jenis +'</span>'+
										'</div>'+
										'<div class="col-md-3">'+
											'<span>'+ hotel.tourhotel_fasilitas +'</span>'+
										'</div>'+
										'<div class="col-md-2">'+
											
										'</div>'+
										'<div class="col-md-12 lines"></div>'+
									'</div>';

				    $(".container-add-hotel").append(content);
				    count_add_hotel++;

				    $("#hotel_jenis, #hotel_fasilitas").val('');
				    $("#tour_hotel_new").val(JSON.stringify(array_hotel_new));
				}

				function setViewHotel(hotel){
					array_hotel = hotel;
					for(var i = 0; i < array_hotel.length; i++){
						var content = '<div class="col-md-12" id="fnb'+array_hotel[i].tourhotel_id+'" style="margin-top: 10px;">'+
											'<div class="col-md-1 text-center">'+
												'<span>'+ (i + 1) +'</span>'+
											'</div>'+
											'<div class="col-md-3">'+
												'<span>'+ array_hotel[i].tourhotel_hotel_name +'</span>'+
											'</div>'+											
											'<div class="col-md-3">'+
												'<span>'+ array_hotel[i].tourhotel_jenis +'</span>'+
											'</div>'+
											'<div class="col-md-3">'+
												'<span>'+ array_hotel[i].tourhotel_fasilitas +'</span>'+
											'</div>'+
											'<div class="col-md-2 text-center">'+
												'<select class="select2" style="width: 100%" id="hotel_status' + array_hotel[i].tourhotel_id +'" onchange="changeStatusHotel('+array_hotel[i].tourhotel_id+');">'+
													'<option value="1">Active</option> '+
													'<option value="3">Cancel</option> '+
												'</select>'+
											'</div>'+
											'<div class="col-md-12 lines"></div>'+
										'</div>';

					    $(".container-add-hotel").append(content);

					    $("#hotel_status"+ array_hotel[i].tourhotel_id).val(array_hotel[i].tourhotel_status);
					    count_add_hotel++
					}
					$(".select2").select2();
				    $("#tour_hotel").val(JSON.stringify(array_hotel));
				}

				function changeStatusHotel(id){
					for (var i = 0; i < array_hotel.length; i++) {
				        if (array_hotel[i]['tourhotel_id'] == id) {
				            array_hotel[i]['tourhotel_status'] = $("#hotel_status" + id).val();
				        }
				    }

				    $("#tour_hotel").val(JSON.stringify(array_hotel));
				}

				function addLayanan(){
					if(!$("#layanan_name").val()){
				        $("#layanan_name").focus();
				        return false;
				    }else if(!$("#layanan_lokasi").val()){
				        $("#layanan_lokasi").focus();
				        return false;
				    }else if(!$("#layanan_jam").val()){
				        $("#layanan_jam").focus();
				        return false;
				    }else if(!$("#layanan_biaya").val()){
				        $("#layanan_biaya").focus();
				        return false;
				    }else if(!$("#layanan_unit").val()){
				        $("#layanan_unit").focus();
				        return false;
				    }else{
				    	viewLayanan();
				    }
				}

				function viewLayanan(){
					var layanan = new Object();
		            layanan['layanan_index'] = count_add_layanan;
		            layanan['layanan_name'] = $("#layanan_name").val();
		            layanan['layanan_lokasi'] = $("#layanan_lokasi").val();
		            layanan['layanan_jam'] = $("#layanan_jam").val();
		            layanan['layanan_biaya'] = $("#layanan_biaya").val();
		            layanan['layanan_unit'] = $("#layanan_unit").val();
		            layanan['layanan_tourdetail_id'] = $("#tourdetail_id").val();

		            array_layanan_new.push(layanan);

				    var content = '<div class="col-md-12" id="layanan'+count_add_layanan+'" style="margin-top: 10px;">'+
										'<div class="col-md-1 text-center">'+
											'<span>'+ layanan.layanan_index +'</span>'+
										'</div>'+
										'<div class="col-md-3">'+
											'<span>'+ layanan.layanan_name +'</span>'+
										'</div>'+
										'<div class="col-md-2">'+
											'<span>'+ layanan.layanan_lokasi +'</span>'+
										'</div>'+
										'<div class="col-md-1">'+
											'<span>'+ layanan.layanan_jam +'</span>'+
										'</div>'+
										'<div class="col-md-2">'+
											'<span>'+ layanan.layanan_biaya +'</span>'+
										'</div>'+
										'<div class="col-md-1 text-center">'+
											'<span>'+ layanan.layanan_unit +'</span>'+
										'</div>'+
										'<div class="col-md-2">'+

										'</div>'+
										'<div class="col-md-12 lines"></div>'+
									'</div>';

				    $(".container-add-layanan").append(content);
				    count_add_layanan++;
				    $("#layanan_name, #layanan_lokasi, #layanan_biaya, #layanan_unit").val('');
				    $("#tour_layanan_new").val(JSON.stringify(array_layanan_new));
				}

				function setViewLayanan(layanan){
					array_layanan = layanan;

					for(var i = 0; i < array_layanan.length; i++){
						var content = '<div class="col-md-12" id="layanan'+array_layanan[i].layanan_index+'" style="margin-top: 10px;">'+
										'<div class="col-md-1 text-center">'+
											'<span>'+ array_layanan[i].layanan_index +'</span>'+
										'</div>'+
										'<div class="col-md-3">'+
											'<span>'+ layanan[i].layanan_name +'</span>'+
										'</div>'+
										'<div class="col-md-2">'+
											'<span>'+ layanan[i].layanan_lokasi +'</span>'+
										'</div>'+
										'<div class="col-md-1">'+
											'<span>'+ layanan[i].layanan_jam +'</span>'+
										'</div>'+
										'<div class="col-md-2">'+
											'<span>'+ layanan[i].layanan_biaya +'</span>'+
										'</div>'+
										'<div class="col-md-1 text-center">'+
											'<span>'+ layanan[i].layanan_unit +'</span>'+
										'</div>'+
										'<div class="col-md-2 text-center">'+
												'<select class="select2" style="width: 100%" id="layanan_status' + layanan[i].layanan_id +'" onchange="changeStatusLayanan('+layanan[i].layanan_id+');">'+
													'<option value="1">Active</option> '+
													'<option value="3">Cancel</option> '+
												'</select>'+
										'</div>'+
										'<div class="col-md-12 lines"></div>'+
									'</div>';

				    	$(".container-add-layanan").append(content);
				    	$("#layanan_status"+ array_layanan[i].layanan_id).val(array_layanan[i].layanan_status);
					    count_add_layanan++
					}
				    
				    $(".select2").select2();
				    $("#tour_layanan").val(JSON.stringify(array_layanan));
				}

				function changeStatusLayanan(id){
					for (var i = 0; i < array_layanan.length; i++) {
				        if (array_layanan[i]['layanan_id'] == id) {
				            array_layanan[i]['layanan_status'] = $("#layanan_status" + id).val();
				        }
				    }

				    $("#tour_layanan").val(JSON.stringify(array_layanan));
				}

				function detailTiket(id){
					var data = new FormData();
				    data.append('troute_id', id);
				    var url = window.location.origin + "/garnis_back_office/tour/get_ticket";

				    $.ajax({
				      url: url,
				      type: 'POST',
				      data: data, 
				      processData: false,
				      contentType: false,
				      dataType: "json",
				      beforeSend: function(e) {
				        if(e && e.overrideMimeType) {
				          e.overrideMimeType("application/json;charset=UTF-8");
				        }
				      },
				      success: function(response){ 
				        if(response.status == "success"){ 

				          if (response.ticket == null){
				          	$("#modal-title").html("Tiket belum tersedia.");
				          }else{
				          	$("#modal-title").html(response.ticket.route_from_text + " - " + response.ticket.route_to_text);

					          $("#tiket_booking").val(response.ticket.ttour_code_book);
					          $("#tiket_maskapai").val(response.ticket.ttour_maskapai);
					          $("#tiket_flight_no").val(response.ticket.ttour_flight_number);
					          $("#tiket_pesawat").val(response.ticket.ttour_jenis_pesawat);
					          $("#tiket_bandara_dept").val(response.ticket.ttour_bandara_dep);
					          $("#tiket_tgl_dep").val(formatDateddmmyyyy(response.ticket.ttour_tgl_dep));
					          $("#tiket_etd").val(response.ticket.ttour_etd);
					          $("#tiket_bandara_arriv").val(response.ticket.ttour_bandara_arriv);
					          $("#tiket_tgl_arriv").val(formatDateddmmyyyy(response.ticket.ttour_tgl_arriv));
					          $("#tiket_eta").val(response.ticket.ttour_eta);

					          getTransit(response.ticket.ttour_id);
				          }
				        }
				       },
				      error: function (xhr, ajaxOptions, thrownError) { 
				        alert(xhr.responseText);
				      }
				    });
				}

				function getTransit(id){
					var data = new FormData();
				    data.append('ttour_id', id);
				    data.append('ttour_origin', 'admin');
				    var url = window.location.origin + "/garnis_back_office/ticketrequest/get_transit";

				    $.ajax({
				      url: url, 
				      type: 'POST', 
				      data: data,
				      processData: false,
				      contentType: false,
				      success: function(response){
				      	$('#table-transit tbody').empty();
            			$('#table-transit tbody').html(response);
				        
				      }
				    });
				}

				function stpcTransit(id){
					$("#id").val(id);
					var data = new FormData();
				    data.append('transit_id', id);
				    var url = window.location.origin + "/garnis_back_office/ticketrequest/get_single_stpc";

				    $.ajax({
				      url: url, 
				      type: 'POST', 
				      data: data,
				      processData: false,
				      contentType: false,
				      dataType: "json",
				      beforeSend: function(e) {
				        if(e && e.overrideMimeType) {
				          e.overrideMimeType("application/json;charset=UTF-8");
				        }
				      },
				      success: function(response){
				        if(response.status == "success"){ 


				           	$("#tiket_stpc_biaya").val(response.data.tstpc_biaya);
				           	$("#tiket_stpc_hotel").val(response.data.tstpc_hotel);

				           if (response.data.tstpc_fullboard == 1) {
				              $("#icheck_fullboard").iCheck('check');
				           }else{
				           	  $("#icheck_fullboard").iCheck('uncheck');
				           	  $("#tiket_penanganan").val(response.data.tstpc_fullboard_penanganan);
				              $("#tiket_akomodasi").val(response.data.tstpc_fullboard_akomodasi);
				           }

				           if (response.data.tstpc_city_tour == 1) {
				              $("#tiket_tour_biaya").val(response.data.tstpc_city_tour_biaya);
				              $("#tiket_tour_biaya").removeAttr('disabled');
				              $("#icheck_city_tour").iCheck('check');
				           }				           
				        }
				      },
				      error: function (xhr, ajaxOptions, thrownError) {
				        alert(xhr.responseText);
				      }
				    });
				}


				function ubahStatus(status) {
					$("#tour_status_new").val(status);
				  	$('#modal-ubah-status').modal('show');
				}

				function formatDateddmmyyyy(date){
				    var dateObj = new Date(date);
				    var month = dateObj.getMonth() + 1; //months from 1-12
				    var day = dateObj.getDate();
				    var year = dateObj.getFullYear();

				    if (day.toString().length == 1) {
				        day = "0" + day;
				    }

				    if (month.toString().length == 1) {
				        month = "0" + month;
				    }

				    var newdate = day + "-" + month + "-" + year;

				    return newdate;
				}

				function minusDate(date, minus){
					
					var dateObj = new Date(date);
					dateObj.setDate(dateObj.getDate() - minus);

				    var month = dateObj.getMonth() + 1; //months from 1-12
				    var day = dateObj.getDate();
				    var year = dateObj.getFullYear();

				    if (day.toString().length == 1) {
				        day = "0" + day;
				    }

				    if (month.toString().length == 1) {
				        month = "0" + month;
				    }

				    var newdate = day + "-" + month + "-" + year;

				    return newdate;
				}
