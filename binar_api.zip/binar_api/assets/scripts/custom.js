var count_add_detail = 2;
var base_url = window.location.origin + "/" + "garnis_back_office/";
var base_url_img = window.location.origin + "/" + "garnis_back_office/assets/img/dokumen/";

function hapusDetailTour(id){
	var counts = count_add_detail--;
    $('#'+id).remove();
}

var user_type = false;

var count_add_flight = 1;
$("#btn-add-flight").click(function(){
    count_add_flight++;
    var content = '<div class="col-md-12">' +
                    '<div class="col-md-3">' +
                      '<div class="form-group">'+
                          '<label>Airline</label>' +
                          '<select class="form-control select2" name="tour_airline_'+ count_add_flight +'" id="tour_airline_'+ count_add_flight +'" style="width: 100%">' +
                          '<option value="0">Pilih Airline</option>' +
                              
                        '</select>' +
                      '</div>' +
                    '</div>' +
                    '<div class="col-md-2">' +
                      '<div class="form-group">' + 
                          '<label>Keberangkatan</label>' +
                          '<div class="input-group">' +
                            '<input type="text" class="form-control date-picker" id="tour_keberangkatan_'+ count_add_flight +'" name="tour_keberangkatan_'+ count_add_flight +'">' +
                            '<div class="input-group-addon">' +
                              '<i class="fa fa-calendar"></i>' +
                            '</div>' +
                          '</div>' +
                      '</div>' +
                    '</div>' +
                    '<div class="col-md-3">' +
                      '<div class="form-group">' +
                          '<label>Asal</label>' +
                          '<select class="form-control select2" name="tour_asal_'+ count_add_flight +'" id="tour_asal_'+ count_add_flight +'" style="width: 100%">' +
                          '<option value="0">Pilih Asal</option>' +
                              
                        '</select>' +
                      '</div>' +
                    '</div>' +
                    '<div class="col-md-3">' +
                      '<div class="form-group">' +
                          '<label>Destinasi</label>' +
                          '<select class="form-control select2" name="tour_des_'+ count_add_flight +'" id="tour_des_'+ count_add_flight +'" style="width: 100%">' +
                          '<option value="0">Pilih Destinasi</option>' +
                              
                        '</select>' +
                      '</div>' +
                    '</div>' +
                    '<div class="col-md-1">' +
                      '<div class="form-group">' +
                          '<label>Qty</label>' +
                          '<input type="number" class="form-control" id="tour_qty_'+ count_add_flight +'" name="tour_qty_'+ count_add_flight +'">' +
                      '</div>' +
                    '</div>' +
                  '</div>' ;

    $(".container-flight").append(content);
});


$('input[type="checkbox"].flat-blue, input[type="radio"].flat-blue').iCheck({
	checkboxClass: 'icheckbox_flat-blue',
	radioClass: 'iradio_flat-blue'
});

$('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
  checkboxClass: 'icheckbox_flat-red',
  radioClass: 'iradio_flat-red'
});

$('input[type="checkbox"].flat-green, input[type="radio"].flat-green').iCheck({
  checkboxClass: 'icheckbox_flat-green',
  radioClass: 'iradio_flat-green'
});


$('#icheck_peserta').on('ifUnchecked', function (event){
	$('#tour_max_peserta').attr('disabled','disabled');
});

$('#btn_back_head_participant').click(function(){
    $('#head_participant').hide();
    $('#add_participant').show();
});

$('#btn_back_payment_participant').click(function(){
    $('#head_participant').show();
    $('#payment_participant').hide();
});

$('#btn_next_payment_participant').click(function(){
    $('#payment_participant').hide();
    $('#detail_participant').show();
});

$('#btn_back_detail_participant').click(function(){
    $('#payment_participant').show();
    $('#detail_participant').hide();
});

$("#pesan-error, #pesan-sukses, #pesan-error-detail, #pesan-error-la, #pesan-error-inner, #pesan-error-pemroh, #pesan-error-vispro").hide();


function isValidEmail(email) {
    var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(email);
}

function saveDivisi(){
    if(!$("#divisi_name").val()){
        $("#pesan-error").html('Nama wajib diisi!').show();
        $("#divisi_name").focus();
        return false;
    }
}

function saveMessage(){
    if(!$("#message").val()){
        $("#message").focus();
        return false;
    }
}

function detailDivisi(id){
  var data = new FormData();
    data.append('divisi_id', id);
    var url = window.location.origin + "/garnis_back_office/divisi/detail";

    $.ajax({
      url: url,
      type: 'POST',
      data: data, 
      processData: false,
      contentType: false,
      dataType: "json",
      beforeSend: function(e) {
        if(e && e.overrideMimeType) {
          e.overrideMimeType("application/json;charset=UTF-8");
        }
      },
      success: function(response){       
        if(response.status == "success"){ 
          $("#divisi_id").val(response.data.divisi_id);
           $("#divisi_name_detail").val(response.data.divisi_name);
        }
       },
      error: function (xhr, ajaxOptions, thrownError) { 
        alert(xhr.responseText);
      }
    });

    if (id <= 6) {
      $("#btn-del-divisi, #btn-upd-divisi").attr('disabled','disabled');
    }else{
      $("#btn-del-divisi, #btn-upd-divisi").removeAttr('disabled');
    }
}

function editDivisi(){
    if(!$("#divisi_name_detail").val()){
        $("#pesan-error-detail").html('Nama wajib diisi!').show();
        $("#divisi_name_detail").focus();
        return false;
    }
}

function deleteDivisi(){
  $("#modal-detail").modal('hide');
  $("#id").val($("#divisi_id").val());
}

function saveUserAccess(){
    if(!$("#user_nopeg").val()){
        $("#pesan-error").html('ID pegawai wajib diisi!').show();
        $("#user_nopeg").focus();
        return false;
    }else if(!$("#user_name").val()){
        $("#pesan-error").html('Nama wajib diisi!').show();
        $("#user_name").focus();
        return false;
    }else if(!$("#user_email").val()){
        $("#pesan-error").html('Email wajib diisi!').show();
        $("#user_email").focus();
        return false;
    }else if(!isValidEmail($("#user_email").val())){
        $("#pesan-error").html('Email tidak valid!').show();
        $("#user_email").focus();
        return false;
    }else if(!$("#user_photo").val()){
        $("#pesan-error").html('Foto wajib diisi!').show();
        $("#user_photo").focus();
        return false;
    }
}

function detailUserAccess(id){

	var data = new FormData();
    data.append('user_id', id);
    var url = window.location.origin + "/garnis_back_office/useraccess/detail";

    $.ajax({
      url: url,
      type: 'POST',
      data: data, 
      processData: false,
      contentType: false,
      dataType: "json",
      beforeSend: function(e) {
        if(e && e.overrideMimeType) {
          e.overrideMimeType("application/json;charset=UTF-8");
        }
      },
      success: function(response){       
        if(response.status == "success"){ 
        	$("#user_id").val(response.data.user_id);
          $("#user_photo_detail").attr("src", base_url_img + response.data.user_photo);
           $("#user_nopeg_detail").val(response.data.user_nopeg);
           $("#user_name_detail").val(response.data.user_name);
           $("#user_email_detail").val(response.data.user_email);
           $("#user_telepon_detail").val(response.data.user_telepon); 
           $("#user_divisi_detail").val(response.data.user_divisi_id).trigger('change'); 
        }
       },
      error: function (xhr, ajaxOptions, thrownError) { 
        alert(xhr.responseText);
      }
    });
}

function editUserAccess(){
    if(!$("#user_nopeg_detail").val()){
        $("#pesan-error-detail").html('ID pegawai wajib diisi!').show();
        $("#user_nopeg_detail").focus();
        return false;
    }else if(!$("#user_name_detail").val()){
        $("#pesan-error-detail").html('Nama wajib diisi!').show();
        $("#user_name_detail").focus();
        return false;
    }else if(!$("#user_email_detail").val()){
        $("#pesan-error-detail").html('Email wajib diisi!').show();
        $("#user_email_detail").focus();
        return false;
    }else if(!isValidEmail($("#user_email_detail").val())){
        $("#pesan-error-detail").html('Email tidak valid!').show();
        $("#user_email_detail").focus();
        return false;
    }
}

function deleteUserAccess(){
	$("#modal-detail").modal('hide');
	$("#id").val($("#user_id").val());
}

function saveHotel(){
    if(!$("#hotel_name").val()){
        $("#pesan-error").html('Nama wajib diisi!').show();
        $("#hotel_name").focus();
        return false;
    }else if(!$("#hotel_pic").val()){
        $("#pesan-error").html('PIC wajib diisi!').show();
        $("#hotel_pic").focus();
        return false;
    }else if(!$("#hotel_pic_email").val()){
        $("#pesan-error").html('Email wajib diisi!').show();
        $("#hotel_pic_email").focus();
        return false;
    }else if(!isValidEmail($("#hotel_pic_email").val())){
        $("#pesan-error").html('Email tidak valid!').show();
        $("#hotel_pic_email").focus();
        return false;
    }else if(!$("#hotel_pic_telepon").val()){
        $("#pesan-error").html('No telepon wajib diisi!').show();
        $("#hotel_pic_telepon").focus();
        return false;
    }else if(!$("#hotel_photo").val()){
        $("#pesan-error").html('Foto wajib diisi!').show();
        $("#hotel_photo").focus();
        return false;
    }
}

function detailHotel(id){

	var data = new FormData();
    data.append('hotel_id', id);
    var url = window.location.origin + "/garnis_back_office/hotel/detail";

    $.ajax({
      url: url,
      type: 'POST',
      data: data, 
      processData: false,
      contentType: false,
      dataType: "json",
      beforeSend: function(e) {
        if(e && e.overrideMimeType) {
          e.overrideMimeType("application/json;charset=UTF-8");
        }
      },
      success: function(response){       
        if(response.status == "success"){ 
        	
        	$("#hotel_id").val(response.data.hotel_id);
          $("#hotel_photo_detail").attr("src", base_url_img + response.data.hotel_photo);
          $("#hotel_name_detail").val(response.data.hotel_name);
          $("#hotel_pic_detail").val(response.data.hotel_pic);
          $("#hotel_pic_email_detail").val(response.data.hotel_pic_email);
          $("#hotel_pic_telepon_detail").val(response.data.hotel_pic_telepon); 
          $("#hotel_latitude_detail").val(response.data.hotel_latitude);
          $("#hotel_longitude_detail").val(response.data.hotel_longitude);
          $("#hotel_alamat_detail").val(response.data.hotel_alamat);

          $('#us3_detail').locationpicker({
    				"location" : {latitude: $('#hotel_latitude_detail').val(), longitude: $('#hotel_longitude_detail').val()},
    				enableAutocomplete: true,
    				radius: 0,
    				inputBinding: {
    					latitudeInput: $('#hotel_latitude_detail'),
    				    longitudeInput: $('#hotel_longitude_detail'),
    				    radiusInput: $('#hotel_radius_detail'),
    				    locationNameInput: $('#hotel_alamat_detail')
    				 }				 
    			});
        }
       },
      error: function (xhr, ajaxOptions, thrownError) { 
        alert(xhr.responseText);
      }
    });
}

function updateHotel(){
    if(!$("#hotel_name_detail").val()){
        $("#pesan-error-detail").html('Nama wajib diisi!').show();
        $("#hotel_name_detail").focus();
        return false;
    }else if(!$("#hotel_pic_detail").val()){
        $("#pesan-error-detail").html('PIC wajib diisi!').show();
        $("#hotel_pic_detail").focus();
        return false;
    }else if(!$("#hotel_pic_email_detail").val()){
        $("#pesan-error-detail").html('Email wajib diisi!').show();
        $("#hotel_pic_email_detail").focus();
        return false;
    }else if(!isValidEmail($("#hotel_pic_email_detail").val())){
        $("#pesan-error-detail").html('Email tidak valid!').show();
        $("#hotel_pic_email_detail").focus();
        return false;
    }else if(!$("#hotel_pic_telepon_detail").val()){
        $("#pesan-error-detail").html('No telepon wajib diisi!').show();
        $("#hotel_pic_telepon_detail").focus();
        return false;
    }
}

function deleteHotel(){
  $("#modal-detail").modal('hide');
  $("#id").val($("#hotel_id").val());
}

function saveVProvider(){
    if(!$("#vprovider_name").val()){
        $("#pesan-error").html('Nama wajib diisi!').show();
        $("#vprovider_name").focus();
        return false;
    }else if(!$("#vprovider_pic").val()){
        $("#pesan-error").html('PIC wajib diisi!').show();
        $("#vprovider_pic").focus();
        return false;
    }else if(!$("#vprovider_email").val()){
        $("#pesan-error").html('Email wajib diisi!').show();
        $("#vprovider_email").focus();
        return false;
    }else if(!isValidEmail($("#vprovider_email").val())){
        $("#pesan-error").html('Email tidak valid!').show();
        $("#vprovider_email").focus();
        return false;
    }else if(!$("#vprovider_telepon").val()){
        $("#pesan-error").html('No telepon wajib diisi!').show();
        $("#vprovider_telepon").focus();
        return false;
    }
}

function detailVProvider(id){

  var data = new FormData();
    data.append('vprovider_id', id);
    var url = window.location.origin + "/garnis_back_office/visaprovider/detail";

    $.ajax({
      url: url,
      type: 'POST',
      data: data, 
      processData: false,
      contentType: false,
      dataType: "json",
      beforeSend: function(e) {
        if(e && e.overrideMimeType) {
          e.overrideMimeType("application/json;charset=UTF-8");
        }
      },
      success: function(response){       
        if(response.status == "success"){ 

          $("#vprovider_id").val(response.data.vprovider_id);
          $("#vprovider_name_detail").val(response.data.vprovider_name);
          $("#vprovider_pic_detail").val(response.data.vprovider_pic);
          $("#vprovider_email_detail").val(response.data.vprovider_email);
          $("#vprovider_telepon_detail").val(response.data.vprovider_telepon); 
        }
       },
      error: function (xhr, ajaxOptions, thrownError) { 
        alert(xhr.responseText);
      }
    });
}

function editVProvider(){
    if(!$("#vprovider_name_detail").val()){
        $("#pesan-error-detail").html('Nama wajib diisi!').show();
        $("#vprovider_name_detail").focus();
        return false;
    }else if(!$("#vprovider_pic_detail").val()){
        $("#pesan-error-detail").html('PIC wajib diisi!').show();
        $("#vprovider_pic_detail").focus();
        return false;
    }else if(!$("#vprovider_email_detail").val()){
        $("#pesan-error-detail").html('Email wajib diisi!').show();
        $("#vprovider_email_detail").focus();
        return false;
    }else if(!isValidEmail($("#vprovider_email_detail").val())){
        $("#pesan-error-detail").html('Email tidak valid!').show();
        $("#vprovider_email_detail").focus();
        return false;
    }else if(!$("#vprovider_telepon_detail").val()){
        $("#pesan-error-detail").html('No telepon wajib diisi!').show();
        $("#vprovider_telepon_detail").focus();
        return false;
    }
}

function deleteVProvider(){
  $("#modal-detail").modal('hide');
  $("#id").val($("#vprovider_id").val());
}

function saveTourLead(){
    if(!$("#tourlead_name").val()){
        $("#pesan-error").html('Nama wajib diisi!').show();
        $("#tourlead_name").focus();
        return false;
    }else if(!$("#tourlead_telepon").val()){
        $("#pesan-error").html('No telepon wajib diisi!').show();
        $("#tourlead_telepon").focus();
        return false;
    }else if(!$("#tourlead_email").val()){
        $("#pesan-error").html('Email wajib diisi!').show();
        $("#tourlead_email").focus();
        return false;
    }else if(!isValidEmail($("#tourlead_email").val())){
        $("#pesan-error").html('Email tidak valid!').show();
        $("#tourlead_email").focus();
        return false;
    }else if(!$("#tourlead_photo").val()){
        $("#pesan-error").html('Foto wajib diisi!').show();
        $("#tourlead_photo").focus();
        return false;
    }
}

function detailTourLead(id){

  var data = new FormData();
    data.append('tourlead_id', id);
    var url = window.location.origin + "/garnis_back_office/tourleader/detail";

    $.ajax({
      url: url,
      type: 'POST',
      data: data, 
      processData: false,
      contentType: false,
      dataType: "json",
      beforeSend: function(e) {
        if(e && e.overrideMimeType) {
          e.overrideMimeType("application/json;charset=UTF-8");
        }
      },
      success: function(response){       
        if(response.status == "success"){ 

          $("#tourlead_id").val(response.data.tourlead_id);
          $("#tourlead_photo_detail").attr("src", base_url_img + response.data.tourlead_photo);
          $("#tourlead_name_detail").val(response.data.tourlead_name);
          $("#tourlead_email_detail").val(response.data.tourlead_email);
          $("#tourlead_telepon_detail").val(response.data.tourlead_telepon);

        }
       },
      error: function (xhr, ajaxOptions, thrownError) { 
        alert(xhr.responseText);
      }
    });
}

function updateTourLead(){
    if(!$("#tourlead_name_detail").val()){
        $("#pesan-error-detail").html('Nama wajib diisi!').show();
        $("#tourlead_name").focus();
        return false;
    }else if(!$("#tourlead_telepon_detail").val()){
        $("#pesan-error-detail").html('No telepon wajib diisi!').show();
        $("#tourlead_telepon_detail").focus();
        return false;
    }else if(!$("#tourlead_email_detail").val()){
        $("#pesan-error-detail").html('Email wajib diisi!').show();
        $("#tourlead_email_detail").focus();
        return false;
    }else if(!isValidEmail($("#tourlead_email_detail").val())){
        $("#pesan-error-detail").html('Email tidak valid!').show();
        $("#tourlead_email_detail").focus();
        return false;
    }
}

function deleteTourLead(){
  $("#modal-detail").modal('hide');
  $("#id").val($("#tourlead_id").val());
}

function savePemRoh(){
    if(!$("#pemroh_name").val()){
        $("#pesan-error").html('Nama wajib diisi!').show();
        $("#pemroh_name").focus();
        return false;
    }else if(!$("#pemroh_telepon").val()){
        $("#pesan-error").html('No telepon wajib diisi!').show();
        $("#pemroh_telepon").focus();
        return false;
    }else if(!$("#pemroh_email").val()){
        $("#pesan-error").html('Email wajib diisi!').show();
        $("#pemroh_email").focus();
        return false;
    }else if(!isValidEmail($("#pemroh_email").val())){
        $("#pesan-error").html('Email tidak valid!').show();
        $("#pemroh_email").focus();
        return false;
    }else if(!$("#pemroh_photo").val()){
        $("#pesan-error").html('Foto wajib diisi!').show();
        $("#pemroh_photo").focus();
        return false;
    }
}

function detailPemRoh(id){

  var data = new FormData();
    data.append('pemroh_id', id);
    var url = window.location.origin + "/garnis_back_office/pembimbingrohani/detail";

    $.ajax({
      url: url,
      type: 'POST',
      data: data, 
      processData: false,
      contentType: false,
      dataType: "json",
      beforeSend: function(e) {
        if(e && e.overrideMimeType) {
          e.overrideMimeType("application/json;charset=UTF-8");
        }
      },
      success: function(response){       
        if(response.status == "success"){ 

          $("#pemroh_id").val(response.data.pemroh_id);
          $("#pemroh_photo_detail").attr("src", base_url_img + response.data.pemroh_photo);
          $("#pemroh_name_detail").val(response.data.pemroh_name);
          $("#pemroh_email_detail").val(response.data.pemroh_email);
          $("#pemroh_telepon_detail").val(response.data.pemroh_telepon);

        }
       },
      error: function (xhr, ajaxOptions, thrownError) { 
        alert(xhr.responseText);
      }
    });
}

function updatePemRoh(){
    if(!$("#pemroh_name_detail").val()){
        $("#pesan-error-detail").html('Nama wajib diisi!').show();
        $("#pemroh_name").focus();
        return false;
    }else if(!$("#pemroh_telepon_detail").val()){
        $("#pesan-error-detail").html('No telepon wajib diisi!').show();
        $("#pemroh_telepon_detail").focus();
        return false;
    }else if(!$("#pemroh_email_detail").val()){
        $("#pesan-error-detail").html('Email wajib diisi!').show();
        $("#pemroh_email_detail").focus();
        return false;
    }else if(!isValidEmail($("#pemroh_email_detail").val())){
        $("#pesan-error-detail").html('Email tidak valid!').show();
        $("#pemroh_email_detail").focus();
        return false;
    }
}

function deletePemRoh(){
  $("#modal-detail").modal('hide');
  $("#id").val($("#pemroh_id").val());
}

function savePurchaseOrder(){
    if(!$("#customer_name").val()){
        $("#pesan-error").html('Nama wajib diisi!').show();
        $("#customer_name").focus();
        return false;
    }else if(!$("#customer_telepon").val()){
        $("#pesan-error").html('Nomor telepon wajib diisi!').show();
        $("#customer_telepon").focus();
        return false;
    }else if(!$("#customer_email").val()){
        $("#pesan-error").html('Email wajib diisi!').show();
        $("#customer_email").focus();
        return false;
    }else if(!isValidEmail($("#customer_email").val())){
        $("#pesan-error").html('Email tidak valid!').show();
        $("#customer_email").focus();
        return false;
    }else if (user_type) {
        if(!$("#customer_total").val()){
            $("#pesan-error").html('Jumlah peserta wajib diisi!').show();
            $("#customer_total").focus();
            return false;
        }
    }
}

function detailPurchase(id){

  var data = new FormData();
    data.append('po_id', id);
    var url = window.location.origin + "/garnis_back_office/customers/get_single_po";

    $.ajax({
      url: url,
      type: 'POST',
      data: data, 
      processData: false,
      contentType: false,
      dataType: "json",
      beforeSend: function(e) {
        if(e && e.overrideMimeType) {
          e.overrideMimeType("application/json;charset=UTF-8");
        }
      },
      success: function(response){       
        if(response.status == "success"){ 
          $("#po_id").val(response.data.po_id);
          $("#customer_name").val(response.data.po_name);
          $("#customer_telepon").val(response.data.po_telepon);
          $("#customer_email").val(response.data.po_email);
          $("#customer_tour").val(response.data.po_tour_id).trigger('change'); 
        }
       },
      error: function (xhr, ajaxOptions, thrownError) { 
        alert(xhr.responseText);
      }
    });
}



function formatDateddmmyyyy(date){
    var dateObj = new Date(date);
    var month = dateObj.getMonth() + 1; //months from 1-12
    var day = dateObj.getDate();
    var year = dateObj.getFullYear();

    if (day.toString().length == 1) {
        day = "0" + day;
    }

    if (month.toString().length == 1) {
        month = "0" + month;
    }

    var newdate = day + "-" + month + "-" + year;

    return newdate;
}

function formatDateyyyymmdd(date){
    var dateObj = new Date(date);
    var month = dateObj.getMonth() + 1; //months from 1-12
    var day = dateObj.getDate();
    var year = dateObj.getFullYear();

    if (day.toString().length == 1) {
        day = "0" + day;
    }

    if (month.toString().length == 1) {
        month = "0" + month;
    }

    var newdate = year + "-" + month + "-" + day;

    return newdate;
}

