			editCustomer($("#customer_id").val());
				var checked_umroh = false;
				var checked_israel = false;

				$('#icheck_israel').on('ifChecked', function (event){
					$('#customer_last_israel').removeAttr('disabled');
					checked_israel = true;
				});

				$('#icheck_israel').on('ifUnchecked', function (event){
					$('#customer_last_israel').val('');
					$('#customer_last_israel').attr('disabled','disabled');
					checked_israel = false;
				});

				$('#icheck_umroh').on('ifChecked', function (event){
					$('#customer_last_umroh').removeAttr('disabled');
					checked_umroh = true;
				});

				$('#icheck_umroh').on('ifUnchecked', function (event){
				  	$('#customer_last_umroh').val('');
				  	$('#customer_last_umroh').attr('disabled','disabled');
				  	checked_umroh = false;
				});

				function editCustomer(id){

				  	var data = new FormData();
				    data.append('customer_id', id);
				    var url = window.location.origin + "/garnis_back_office/customers/get_single_customer";

				    $.ajax({
				      url: url,
				      type: 'POST',
				      data: data, 
				      processData: false,
				      contentType: false,
				      dataType: "json",
				      beforeSend: function(e) {
				        if(e && e.overrideMimeType) {
				          e.overrideMimeType("application/json;charset=UTF-8");
				        }
				      },
				      success: function(response){  
				      	console.log(response);       
				        if(response.status == "success"){ 
				          $("#customer_id").val(response.data.customer_id);
				          $("#customer_nik").val(response.data.customer_nik);
				          $("#customer_name").val(response.data.customer_name);
				          $("#customer_kelamin").val(response.data.customer_jk).trigger('change');
				          $("#customer_lahir").val(response.data.customer_tempat_lahir);
				          $("#customer_tgl_lahir").datepicker("update", formatDateddmmyyyy(response.data.customer_tgl_lahir));
				          $("#customer_kwn").val(response.data.customer_kewarganegaraan);
				          $("#customer_pekerjaan").val(response.data.customer_pekerjaan);
				          $("#customer_pernikahan").val(response.data.customer_status_nikah).trigger('change');
				          $("#customer_hubungan").val(response.data.customer_hub_keluarga).trigger('change');
				          $("#customer_ibu").val(response.data.customer_ibu);
				          $("#customer_ayah").val(response.data.customer_ayah);
				          $("#customer_kakek").val(response.data.customer_kakek);
				          $("#customer_pekerjaan").val(response.data.customer_pekerjaan);
				          $("#customer_email").val(response.data.customer_email);
				          $("#customer_telepon").val(response.data.customer_telepon);

				          $("#customer_passport").val(response.data.passport_number);
				          $("#customer_passport_penerbit").val(response.data.passport_issue);

				          if (response.data.passport_number != "") {
					          $("#customer_passport_tgl").datepicker("update", formatDateddmmyyyy(response.data.passport_issue_date));
					          $("#customer_passport_tgl_akhir").datepicker("update", formatDateddmmyyyy(response.data.passport_expire));
					      }
				          $("#customer_last_tour").val(response.data.customer_negara_akhir_kunjung);

				          if (response.data.tour_sub_category == 2) {
				          		$("#customer_umroh_view").hide();
              					$("#customer_israel_view").show();
				          	 	if (response.data.customer_pernah_israel == 'Y') {
				          	 		$("#icheck_israel").iCheck('check');
				          	 		$("#customer_last_israel").datepicker("update", formatDateddmmyyyy(response.data.customer_tgl_akhir_israel));
				          	 	}
				          }else if (response.data.tour_sub_category == 1){
				          		$("#customer_umroh_view").show();
              					$("#customer_israel_view").hide();
				          		if (response.data.customer_pernah_umroh == 'Y') {
					          	 	$("#icheck_umroh").iCheck('check');
					          	 	$("#customer_last_umroh").datepicker("update", formatDateddmmyyyy(response.data.customer_tgl_akhir_umroh));

					          	}
				          }else{
				          		$("#customer_umroh_view").hide();
              					$("#customer_israel_view").hide();
				          }

				          $("#customer_passport_file_name").html(response.data.customer_file_passport);
				          $("#customer_ktp_file_name").html(response.data.customer_file_ktp);
				          $("#customer_foto_file_name").html(response.data.customer_file_foto);
				        }
				       },
				      error: function (xhr, ajaxOptions, thrownError) { 
				        alert(xhr.responseText);
				      }
				    });
				}

				function saveDetailCustomer(){
					if(!$("#customer_nik").val()){
				        $("#pesan-error").html('NIK wajib diisi!').show();
				        $("#customer_nik").focus();
				        return false;
				    }else if(!$("#customer_name").val()){
				        $("#pesan-error").html('Nama wajib diisi!').show();
				        $("#customer_name").focus();
				        return false;
				    }else if(!$("#customer_lahir").val()){
				        $("#pesan-error").html('Tempat lahir wajib diisi!').show();
				        $("#customer_lahir").focus();
				        return false;
				    }else if(!$("#customer_tgl_lahir").val()){
				        $("#pesan-error").html('Tanggal lahir wajib diisi!').show();
				        $("#customer_tgl_lahir").focus();
				        return false;
				    }else if(!$("#customer_kwn").val()){
				        $("#pesan-error").html('Kewarganegaraan wajib diisi!').show();
				        $("#customer_kwn").focus();
				        return false;
				    }else if(!$("#customer_pekerjaan").val()){
				        $("#pesan-error").html('Pekerjaan wajib diisi!').show();
				        $("#customer_pekerjaan").focus();
				        return false;
				    }else if(!$("#customer_ibu").val()){
				        $("#pesan-error").html('Nama ibu wajib diisi!').show();
				        $("#customer_ibu").focus();
				        return false;
				    }else if(!$("#customer_ayah").val()){
				        $("#pesan-error").html('Nama ayah wajib diisi!').show();
				        $("#customer_ayah").focus();
				        return false;
				    }else if(!$("#customer_kakek").val()){
				        $("#pesan-error").html('Nama kakek wajib diisi!').show();
				        $("#customer_kakek").focus();
				        return false;
				    }/*else if(!$("#customer_passport").val()){
				        $("#pesan-error").html('Nomor passport wajib diisi!').show();
				        $("#customer_passport").focus();
				        return false;
				    }else if(!$("#customer_passport_penerbit").val()){
				        $("#pesan-error").html('Negara penerbit wajib diisi!').show();
				        $("#customer_passport_penerbit").focus();
				        return false;
				    }else if(!$("#customer_passport_tgl").val()){
				        $("#pesan-error").html('Tanggal terbit passport wajib diisi!').show();
				        $("#customer_passport_tgl").focus();
				        return false;
				    }else if(!$("#customer_passport_tgl_akhir").val()){
				        $("#pesan-error").html('Tanggal masa berlaku passport wajib diisi!').show();
				        $("#customer_passport_tgl_akhir").focus();
				        return false;
				    }*/else if (checked_umroh) {
				        if(!$("#customer_last_umroh").val()){
				            $("#pesan-error").html('Tanggal terakhir umroh wajib diisi!').show();
				            $("#customer_last_umroh").focus();
				            return false;
				        }
				    }else if (checked_israel) {
				        if(!$("#customer_last_israel").val()){
				            $("#pesan-error").html('Tanggal terakhir ke Israel wajib diisi!').show();
				            $("#customer_last_israel").focus();
				            return false;
				        }
				    }
				}

				function uploadPassport(){
					if (!$("#customer_passport_file").val()) {
						$("#customer_passport_file").focus();
					}else{

					  	var data = new FormData();
					    data.append('customer_id', $("#customer_id").val());
					    data.append('customer_passport_file', $("#customer_passport_file")[0].files[0]);
					    var url = window.location.origin + "/garnis_back_office/customers/upload_passport";

					    $.ajax({
					      url: url,
					      type: 'POST',
					      data: data, 
					      processData: false,
					      contentType: false,
					      dataType: "json",
					      beforeSend: function(e) {
					        if(e && e.overrideMimeType) {
					          e.overrideMimeType("application/json;charset=UTF-8");
					        }
					      },
					      success: function(response){  
					      	alert(response.message);
					      	if (response.status == 'success') {
					      		$("#customer_passport_file_name").html(response.file_name);
					      	}
					       },
					      error: function (xhr, ajaxOptions, thrownError) { 
					        alert(xhr.responseText);
					      }
					    });
					}
				}

				function uploadKTP(){
					if (!$("#customer_ktp_file").val()) {
						$("#customer_ktp_file").focus();
					}else{

					  	var data = new FormData();
					    data.append('customer_id', $("#customer_id").val());
					    data.append('customer_ktp_file', $("#customer_ktp_file")[0].files[0]);
					    var url = window.location.origin + "/garnis_back_office/customers/upload_ktp";

					    $.ajax({
					      url: url,
					      type: 'POST',
					      data: data, 
					      processData: false,
					      contentType: false,
					      dataType: "json",
					      beforeSend: function(e) {
					        if(e && e.overrideMimeType) {
					          e.overrideMimeType("application/json;charset=UTF-8");
					        }
					      },
					      success: function(response){  
					      	alert(response.message);
					      	if (response.status == 'success') {
					      		$("#customer_ktp_file_name").html(response.file_name);
					      	}
					       },
					      error: function (xhr, ajaxOptions, thrownError) { 
					        alert(xhr.responseText);
					      }
					    });
					}
				}

				function uploadFoto(){
					if (!$("#customer_foto_file").val()) {
						$("#customer_foto_file").focus();
					}else{

					  	var data = new FormData();
					    data.append('customer_id', $("#customer_id").val());
					    data.append('customer_foto_file', $("#customer_foto_file")[0].files[0]);
					    var url = window.location.origin + "/garnis_back_office/customers/upload_foto";

					    $.ajax({
					      url: url,
					      type: 'POST',
					      data: data, 
					      processData: false,
					      contentType: false,
					      dataType: "json",
					      beforeSend: function(e) {
					        if(e && e.overrideMimeType) {
					          e.overrideMimeType("application/json;charset=UTF-8");
					        }
					      },
					      success: function(response){  
					      	alert(response.message);
					      	if (response.status == 'success') {
					      		$("#customer_foto_file_name").html(response.file_name);
					      	}
					       },
					      error: function (xhr, ajaxOptions, thrownError) { 
					        alert(xhr.responseText);
					      }
					    });
					}
				}