				$('#pesan-error-passport').hide();

				var checked_umroh = false;
				var checked_israel = false;
				var index = 1;
				var customers = jQuery.parseJSON($("#customer_purchase").val()).po_qty;
				var array_detail = new Array();

				for (var i = 0; i < customers; i++) {
					var detail = new Object();

					detail['customer_index'] = "";
					detail['customer_nik'] = "";
					detail['customer_name'] = "";
					detail['customer_jk'] = "1";
					detail['customer_tempat_lahir'] = "";
					detail['customer_tgl_lahir'] = "";
					detail['customer_status_nikah'] = "1";
					detail['customer_kewarganegaraan'] = "";
					detail['customer_pekerjaan'] = "";
					detail['customer_telepon'] = "";
					detail['customer_email'] = "";
					detail['customer_ibu'] = "";
					detail['customer_ayah'] = "";
					detail['customer_kakek'] = "";
					detail['customer_hub_keluarga'] = "1";
					/*detail['customer_passport_no'] = "";
					detail['customer_passport_penerbit'] = "";
					detail['customer_passport_tgl_terbit'] = "";
					detail['customer_passport_tgl_akhir'] = "";*/
					detail['customer_negara_akhir_kunjung'] = "";
					detail['customer_pernah_israel'] = "";
					detail['customer_pernah_umroh'] = "";
					detail['customer_tgl_akhir_israel'] = "";
					detail['customer_tgl_akhir_umroh'] = "";

					array_detail.push(detail);
				}

				console.log(array_detail);

				if (customers == 1) {
					$("#btn-next-detail-customer").html('<span class="glyphicon glyphicon-ok"></span> Selesai');
				}

				$('#icheck_israel').on('ifChecked', function (event){
					$('#customer_last_israel').removeAttr('disabled');
					checked_israel = true;
					$(this).val('Y');
				});

				$('#icheck_israel').on('ifUnchecked', function (event){
					$('#customer_last_israel').val('');
					$('#customer_last_israel').attr('disabled','disabled');
					checked_israel = false;
					$(this).val('N');
				});

				$('#icheck_umroh').on('ifChecked', function (event){
					$('#customer_last_umroh').removeAttr('disabled');
					checked_umroh = true;
					$(this).val('Y');
				});

				$('#icheck_umroh').on('ifUnchecked', function (event){
				  	$('#customer_last_umroh').val('');
				  	$('#customer_last_umroh').attr('disabled','disabled');
				  	checked_umroh = false;
				  	$(this).val('N');
				});

				$("#btn-back-detail-customer").hide();

				function saveCuts(){
					$("#btn-next-detail-customer").attr('disabled', 'disabled');
				}

				function saveDetailCustomer(){
					if(!$("#customer_nik").val()){
				        $("#pesan-error").html('NIK wajib diisi!').show();
				        $("#customer_nik").focus();
				        return false;
				    }else if(!$("#customer_name").val()){
				        $("#pesan-error").html('Nama wajib diisi!').show();
				        $("#customer_name").focus();
				        return false;
				    }else if(!$("#customer_lahir").val()){
				        $("#pesan-error").html('Tempat lahir wajib diisi!').show();
				        $("#customer_lahir").focus();
				        return false;
				    }else if(!$("#customer_tgl_lahir").val()){
				        $("#pesan-error").html('Tanggal lahir wajib diisi!').show();
				        $("#customer_tgl_lahir").focus();
				        return false;
				    }else if(!$("#customer_kwn").val()){
				        $("#pesan-error").html('Kewarganegaraan wajib diisi!').show();
				        $("#customer_kwn").focus();
				        return false;
				    }else if(!$("#customer_pekerjaan").val()){
				        $("#pesan-error").html('Pekerjaan wajib diisi!').show();
				        $("#customer_pekerjaan").focus();
				        return false;
				    }else if(!$("#customer_ibu").val()){
				        $("#pesan-error").html('Nama ibu wajib diisi!').show();
				        $("#customer_ibu").focus();
				        return false;
				    }else if(!$("#customer_ayah").val()){
				        $("#pesan-error").html('Nama ayah wajib diisi!').show();
				        $("#customer_ayah").focus();
				        return false;
				    }else if(!$("#customer_kakek").val()){
				        $("#pesan-error").html('Nama kakek wajib diisi!').show();
				        $("#customer_kakek").focus();
				        return false;
				    }/*else if(!$("#customer_passport").val()){
				        $("#pesan-error").html('Nomor passport wajib diisi!').show();
				        $("#customer_passport").focus();
				        return false;
				    }else if(!$("#customer_passport_penerbit").val()){
				        $("#pesan-error").html('Negara penerbit wajib diisi!').show();
				        $("#customer_passport_penerbit").focus();
				        return false;
				    }else if(!$("#customer_passport_tgl").val()){
				        $("#pesan-error").html('Tanggal terbit passport wajib diisi!').show();
				        $("#customer_passport_tgl").focus();
				        return false;
				    }else if(!$("#customer_passport_tgl_akhir").val()){
				        $("#pesan-error").html('Tanggal masa berlaku passport wajib diisi!').show();
				        $("#customer_passport_tgl_akhir").focus();
				        return false;
				    }*/else if (checked_umroh) {
				        if(!$("#customer_last_umroh").val()){
				            $("#pesan-error").html('Tanggal terakhir umroh wajib diisi!').show();
				            $("#customer_last_umroh").focus();
				            return false;
				        }else{
					    	$("#pesan-error").hide();
					    	return true;
					    }
				    }else if (checked_israel) {
				        if(!$("#customer_last_israel").val()){
				            $("#pesan-error").html('Tanggal terakhir ke Israel wajib diisi!').show();
				            $("#customer_last_israel").focus();
				            return false;
				        }else{
					    	$("#pesan-error").hide();
					    	return true;
					    }
				    }else{
				    	$("#pesan-error").hide();
				    	return true;
				    }
				}

				$("#customer_passport_tgl_akhir").change(function(){
					var tgl_berangkat = $("#tgl_berangkat").val();
					var due = addMonth(7, tgl_berangkat);
					var diff = dateDiff(due, $(this).val());
					if (diff < 0) {
						$('#pesan-error-passport').show();
						$(this).focus();
					}else{
						$('#pesan-error-passport').hide();
					}
				});

				history.pushState(null, null, location.href);
			      window.onpopstate = function () {
			          history.go(1);
			      };

			    function save() {
					if (index < customers) {

						if (saveDetailCustomer()) {
							$("#number_customer").html((index + 1) + "/" + customers);

							if (index >= 1) {
								$("#btn-back-detail-customer").show();
								$("#btn-next-detail-customer").html('Selanjutnya <span class="glyphicon glyphicon-chevron-right"></span>');
							}

							var count =  index - 1;

							array_detail[count].customer_index = index;
							array_detail[count].customer_nik = $("#customer_nik").val();
							array_detail[count].customer_name = $("#customer_name").val();
							array_detail[count].customer_jk = $("#customer_kelamin").val();
							array_detail[count].customer_tempat_lahir = $("#customer_lahir").val();
							array_detail[count].customer_tgl_lahir = $("#customer_tgl_lahir").val();
							array_detail[count].customer_status_nikah = $("#customer_pernikahan").val();
							array_detail[count].customer_kewarganegaraan = $("#customer_kwn").val();
							array_detail[count].customer_pekerjaan = $("#customer_pekerjaan").val();
							array_detail[count].customer_telepon = $("#customer_telepon").val();
							array_detail[count].customer_email = $("#customer_email").val();
							array_detail[count].customer_ibu = $("#customer_ibu").val();							
							array_detail[count].customer_ayah = $("#customer_ayah").val();
							array_detail[count].customer_kakek = $("#customer_kakek").val();
							array_detail[count].customer_hub_keluarga = $("#customer_hubungan").val();/*
							array_detail[count].customer_passport_no = $("#customer_passport").val();
							array_detail[count].customer_passport_penerbit = $("#customer_passport_penerbit").val();
							array_detail[count].customer_passport_tgl_terbit = $("#customer_passport_tgl").val();
							array_detail[count].customer_passport_tgl_akhir =$("#customer_passport_tgl_akhir").val();*/
							array_detail[count].customer_negara_akhir_kunjung = $("#customer_last_tour").val();
							array_detail[count].customer_pernah_israel = $("#icheck_israel").val();
							array_detail[count].customer_pernah_umroh = $("#icheck_umroh").val();
							array_detail[count].customer_tgl_akhir_israel = $("#customer_last_israel").val();
							array_detail[count].customer_tgl_akhir_umroh = $("#customer_last_umroh").val();

							index++;

							if(customers == index){
								$("#btn-next-detail-customer").html('<span class="glyphicon glyphicon-ok"></span> Selesai');
							}

							setValueDetail(array_detail[index - 1]);
						}

					}else if(index == customers){
						if (saveDetailCustomer()) {
							var count =  index - 1;
							
							array_detail[count].customer_index = index;
							array_detail[count].customer_nik = $("#customer_nik").val();
							array_detail[count].customer_name = $("#customer_name").val();
							array_detail[count].customer_jk = $("#customer_kelamin").val();
							array_detail[count].customer_tempat_lahir = $("#customer_lahir").val();
							array_detail[count].customer_tgl_lahir = $("#customer_tgl_lahir").val();
							array_detail[count].customer_status_nikah = $("#customer_pernikahan").val();
							array_detail[count].customer_kewarganegaraan = $("#customer_kwn").val();
							array_detail[count].customer_pekerjaan = $("#customer_pekerjaan").val();
							array_detail[count].customer_telepon = $("#customer_telepon").val();
							array_detail[count].customer_email = $("#customer_email").val();
							array_detail[count].customer_ibu = $("#customer_ibu").val();							
							array_detail[count].customer_ayah = $("#customer_ayah").val();
							array_detail[count].customer_kakek = $("#customer_kakek").val();
							array_detail[count].customer_hub_keluarga = $("#customer_hubungan").val();
							/*array_detail[count].customer_passport_no = $("#customer_passport").val();
							array_detail[count].customer_passport_penerbit = $("#customer_passport_penerbit").val();
							array_detail[count].customer_passport_tgl_terbit = $("#customer_passport_tgl").val();
							array_detail[count].customer_passport_tgl_akhir =$("#customer_passport_tgl_akhir").val();*/
							array_detail[count].customer_negara_akhir_kunjung = $("#customer_last_tour").val();
							array_detail[count].customer_pernah_israel = $("#icheck_israel").val();
							array_detail[count].customer_pernah_umroh = $("#icheck_umroh").val();
							array_detail[count].customer_tgl_akhir_israel = $("#customer_last_israel").val();
							array_detail[count].customer_tgl_akhir_umroh = $("#customer_last_umroh").val();

							$('#data_detail_customer').val(JSON.stringify(array_detail));
							$('#modal-finish').modal('show');
						}
					}

				}

				function edit() {
					if (index <= customers) {

						$("#number_customer").html((index - 1) + "/" + customers);

						var count =  index - 1;
						array_detail[count].customer_index = index;
						array_detail[count].customer_nik = $("#customer_nik").val();
						array_detail[count].customer_name = $("#customer_name").val();
						array_detail[count].customer_jk = $("#customer_kelamin").val();
						array_detail[count].customer_tempat_lahir = $("#customer_lahir").val();
						array_detail[count].customer_tgl_lahir = $("#customer_tgl_lahir").val();
						array_detail[count].customer_status_nikah = $("#customer_pernikahan").val();
						array_detail[count].customer_kewarganegaraan = $("#customer_kwn").val();
						array_detail[count].customer_pekerjaan = $("#customer_pekerjaan").val();
						array_detail[count].customer_telepon = $("#customer_telepon").val();
						array_detail[count].customer_email = $("#customer_email").val();
						array_detail[count].customer_ibu = $("#customer_ibu").val();							
						array_detail[count].customer_ayah = $("#customer_ayah").val();
						array_detail[count].customer_kakek = $("#customer_kakek").val();
						array_detail[count].customer_hub_keluarga = $("#customer_hubungan").val();
						/*array_detail[count].customer_passport_no = $("#customer_passport").val();
						array_detail[count].customer_passport_penerbit = $("#customer_passport_penerbit").val();
						array_detail[count].customer_passport_tgl_terbit = $("#customer_passport_tgl").val();
						array_detail[count].customer_passport_tgl_akhir =$("#customer_passport_tgl_akhir").val();*/
						array_detail[count].customer_negara_akhir_kunjung = $("#customer_last_tour").val();
						array_detail[count].customer_pernah_israel = $("#icheck_israel").val();
						array_detail[count].customer_pernah_umroh = $("#icheck_umroh").val();
						array_detail[count].customer_tgl_akhir_israel = $("#customer_last_israel").val();
						array_detail[count].customer_tgl_akhir_umroh = $("#customer_last_umroh").val();

						if (index >= 1) {
							$("#btn-back-detail-customer").show();
							$("#btn-next-detail-customer").html('Selanjutnya <span class="glyphicon glyphicon-chevron-right"></span>');
						}

						index--;

						if(index == 1){
							$("#btn-back-detail-customer").hide();
						}

						setValueDetail(array_detail[index - 1]);
					}

					console.log(array_detail);
				}

				function setValueDetail(obj){
					$("#customer_nik").val(obj.customer_nik);
					$("#customer_name").val(obj.customer_name);
					$("#customer_kelamin").val(obj.customer_jk).trigger('change');
					$("#customer_lahir").val(obj.customer_tempat_lahir);
					$("#customer_tgl_lahir").val(obj.customer_tgl_lahir).trigger('change');
					$("#customer_pernikahan").val(obj.customer_status_nikah).trigger('change');
					$("#customer_kwn").val(obj.customer_kewarganegaraan);
					$("#customer_pekerjaan").val(obj.customer_pekerjaan);
					$("#customer_telepon").val(obj.customer_telepon);
					$("#customer_email").val(obj.customer_email);
					$("#customer_ibu").val(obj.customer_ibu);							
					$("#customer_ayah").val(obj.customer_ayah);
					$("#customer_kakek").val(obj.customer_kakek);
					$("#customer_hubungan").val(obj.customer_hub_keluarga).trigger('change');
					/*$("#customer_passport").val(obj.customer_passport_no);
					$("#customer_passport_penerbit").val(obj.customer_passport_penerbit);
					$("#customer_passport_tgl").val(obj.customer_passport_tgl_terbit).trigger('change');
					$("#customer_passport_tgl_akhir").val(obj.customer_passport_tgl_akhir).trigger('change');*/
					$("#customer_last_tour").val(obj.customer_negara_akhir_kunjung);

					if (obj.customer_pernah_israel == 'Y') {
						$("#icheck_israel").iCheck('check');
					}else{
						$("#icheck_israel").iCheck('uncheck');
					}
 
					if (obj.customer_pernah_umroh == 'Y') {
						$("#icheck_umroh").iCheck('check');
					}else{
						$("#icheck_umroh").iCheck('uncheck');
					}

					$("#customer_last_israel").val(obj.customer_tgl_akhir_israel);
					$("#customer_last_umroh").val(obj.customer_tgl_akhir_umroh);
				}

				function dateDiff(dt1, dt2){
				   	var a = moment(dt1,'DD-MM-YYYY');
					var b = moment(dt2,'DD-MM-YYYY');
					return diffDays = b.diff(a, 'days');
				}

				function addMonth(count, date){
					var dates = moment(date);
					var futureMonth = moment(dates).add(count, 'M');
					var futureMonthEnd = moment(futureMonth).endOf('month');

					if(dates.date() != futureMonth.date() && futureMonth.isSame(futureMonthEnd.format('YYYY-MM-DD'))) {
					    futureMonth = futureMonth.add(count, 'd');
					}

					return futureMonth.format('DD-MM-YYYY');

				}
