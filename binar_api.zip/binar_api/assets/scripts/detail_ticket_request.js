
	$("#ticket_status").val($("#status").val());

	$( "#ticket_status" ).change(function() {
	  	$("#trequest_status").val($(this).val());
	  	$("#ticket_status").val($("#status").val());
	  	$('#modal-finish').modal('show');
	});