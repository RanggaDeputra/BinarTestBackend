				function save(){
					if(!$("#blacklist_alasan").val()){
				        $("#blacklist_alasan").focus();
				        return false;
				    }else{
				    	$('#modal-blacklist').modal('show'); 
				    }
				}

				function submitForm(){
					$("#form-blacklist").submit();
				}