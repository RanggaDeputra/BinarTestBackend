
				var total_tour = 0;
				var total_passport = 0;
				var total_visa = 0;
				var total_layanan = 0;
				var voucher = 0;

				get_po_tour($('#po_id').val());

				function get_po_tour(id){

					var data = new FormData();
				    data.append('purchase_id', id);
				    var url = window.location.origin + "/garnis_back_office/customers/get_po_tour";

				    $.ajax({
				      url: url,
				      type: 'POST',
				      data: data, 
				      processData: false,
				      contentType: false,
				      dataType: "json",
				      beforeSend: function(e) {
				        if(e && e.overrideMimeType) {
				          e.overrideMimeType("application/json;charset=UTF-8");
				        }
				      },
				      success: function(response){       
				        if(response.status == "success"){ 

				        	$("#po_id").val(response.data.po_id);
				        	setCustomerTour(response.customer_tour);
				        	setCustomerPassport(response.customer_passport);
				        	setCustomerVisa(response.customer_visa);
				        	setCustomerLayanan(response.layanan);

				        	setTotal();
				        	
				        }
				       },
				      error: function (xhr, ajaxOptions, thrownError) { 
				        alert(xhr.responseText);
				      }, 
				      async: false
				    });
				}


				$("#po_voucher").change(function (){
					voucher = parseInt($(this).val().split('.').join(""));
					setTotal();
				});

				getVocuher($('#po_id').val());

				function getVocuher(id){
					var data = new FormData();
				    data.append('po_id', id);
				    var url = window.location.origin + "/garnis_back_office/customers/get_voucher";

				    $.ajax({
				      url: url,
				      type: 'POST',
				      data: data, 
				      processData: false,
				      contentType: false,
				      dataType: "json",
				      beforeSend: function(e) {
				        if(e && e.overrideMimeType) {
				          e.overrideMimeType("application/json;charset=UTF-8");
				        }
				      },
				      success: function(response){       

				        if(response.status == "success"){ 
				        	$("#po_voucher").val(response.data.voucher_value).trigger('paste');		
				        	$("#po_voucher").trigger('change');			
				        	$("#po_kode_voucher").val(response.data.voucher_kode);				        	
				        }
				       },
				      error: function (xhr, ajaxOptions, thrownError) { 
				        alert(xhr.responseText);
				      }, 
				      async: false
				    });
				}

				function setTotal(){

				    var total = (total_tour + total_passport + total_visa + total_layanan) - voucher;

				    $("#po_total").html('Grand Total : Rp' + convertToRupiah(total));
				}

				function setCustomerTour(customer_tour){
					for(var i = 0; i < customer_tour.length; i++){
				        		var content = '<tr>'
				        							+ '<td class="text-center">' +  (i+1) + '</td>'
													+ '<td>' +  customer_tour[i].customer_name + '</td>'
													+ '<td>' +  customer_tour[i].tour_name + '</td>'
													+ '<td class="text-center">' +  formatDateddmmyyyy(customer_tour[i].tour_tgl_berangkat) + '</td>'
													+ '<td> Rp' +  convertToRupiah(customer_tour[i].tour_biaya) + '</td>'+
												'</tr>';

								$('#table-customer tbody').append(content);

								total_tour += parseInt(customer_tour[i].tour_biaya);

				        	}

				}

				function setCustomerPassport(customer_passport){
					for(var i = 0; i < customer_passport.length; i++){
				        		var content = '<tr>'
				        							+ '<td class="text-center">' +  (i+1) + '</td>'
													+ '<td>' +  customer_passport[i].customer_name + '</td>'
													+ '<td> Rp' +  convertToRupiah(customer_passport[i].passport_biaya) + '</td>'+
												'</tr>';

								$('#table-passport tbody').append(content);
								total_passport += parseInt(customer_passport[i].passport_biaya);
				        	}

				}

				function setCustomerVisa(customer_visa){
					for(var i = 0; i < customer_visa.length; i++){
				        		var content = '<tr>'
				        							+ '<td class="text-center">' +  (i+1) + '</td>'
													+ '<td>' +  customer_visa[i].customer_name + '</td>'
													+ '<td> Rp' +  convertToRupiah(customer_visa[i].visa_biaya) + '</td>'+
												'</tr>';

								$('#table-visa tbody').append(content);
								total_visa += parseInt(customer_visa[i].visa_biaya);
				        	}

				}

				function setCustomerLayanan(customer_layanan){
					for(var i = 0; i < customer_layanan.length; i++){
				        		var content = '<tr>'
				        							+ '<td class="text-center">' +  (i+1) + '</td>'
													+ '<td>' +  customer_layanan[i].customer_name + '</td>'
													+ '<td>' +  customer_layanan[i].layanan_name + '</td>'
													+ '<td> Rp' +  customer_layanan[i].layanan_biaya + '</td>'+
												'</tr>';

								$('#table-layanan tbody').append(content);
								total_layanan += parseInt(customer_layanan[i].layanan_biaya.split('.').join(""));
				        	}

				}

				$("#pesan-voucher").hide();
				function saveVoucher(){
				    if($("#po_voucher").val().length > 0){
				    	if (!$("#po_kode_voucher").val()) {
				    		$("#pesan-voucher").html('Kode voucher wajib diisi!').show();
					        $("#po_kode_voucher").focus();
					        return false;
				    	}/*else if (!$("#po_file_voucher").val()) {
				    		$("#pesan-voucher").html('Bukti voucher wajib diisi!').show();
					        $("#po_file_voucher").focus();
					        return false;
				    	}*/
				    }
				}

				$("#pesan-method").hide();
				function saveMedthod(){
				    if($("#payment_method").val() == 2){
				    	if (!$("#nominal_dp").val()) {
				    		$("#pesan-method").html('Nominal DP wajib diisi!').show();
					        $("#nominal_dp").focus();
					        return false;
				    	}
				    	if ($("#method_dp").val() == 2) {
				    		if (!$("#cicilan_dp").val()) {
					    		$("#pesan-method").html('Ciclan DP wajib diisi!').show();
						        $("#cicilan_dp").focus();
						        return false;
				    		}
				    	}
				    }
				}

				$("#dp_method_view").hide();
				$("#payment_method").change(function(){
					if ($(this).val() == 1) {
						$("#dp_method_view").hide();
						$("#nominal_dp").val('');
						$("#cicilan_dp").val('');
					}else{
						$("#dp_method_view").show();
					}
				});

				$("#cicilan_dp_view").hide();
				$("#method_dp").change(function(){
					if ($(this).val() == 1) {
						$("#cicilan_dp_view").hide();
						$("#cicilan_dp").val('');
					}else{
						$("#cicilan_dp_view").show();
					}
				});

				getPayemnt($('#po_id').val());

				function getPayemnt(id){
					var data = new FormData();
				    data.append('po_id', id);
				    var url = window.location.origin + "/garnis_back_office/customers/get_payment";

				    $.ajax({
				      url: url,
				      type: 'POST',
				      data: data, 
				      processData: false,
				      contentType: false,
				      dataType: "json",
				      beforeSend: function(e) {
				        if(e && e.overrideMimeType) {
				          e.overrideMimeType("application/json;charset=UTF-8");
				        }
				      },
				      success: function(response){       
				      	console.log(response);
				        if(response.status == "success"){ 
				        	$("#payment_method").val(response.data.payment_method).trigger('change');			
				        	$("#nominal_dp").val(response.data.payment_nominal).trigger('paste');		
				        	$("#method_dp").val(response.data.payment_dp_method).trigger('change')		
				        	$("#cicilan_dp").val(response.data.payment_dp_cicilan);				        	
				        }else{
				        	$("#payment_method").val(1).trigger('change');			
				        	$("#nominal_dp").val('');	
				        	$("#method_dp").val(1).trigger('change')		
				        	$("#cicilan_dp").val('');			
				        }
				       },
				      error: function (xhr, ajaxOptions, thrownError) { 
				        alert(xhr.responseText);
				      }, 
				      async: false
				    });
				}

				function convertToRupiah(angka){
				  var rupiah = '';    
				  var angkarev = angka.toString().split('').reverse().join('');
				  for(var i = 0; i < angkarev.length; i++) if(i%3 == 0) rupiah += angkarev.substr(i,3)+'.';
				  return rupiah.split('',rupiah.length-1).reverse().join('');
				}

				function formatDateddmmyyyy(date){
				    var dateObj = new Date(date);
				    var month = dateObj.getMonth() + 1; //months from 1-12
				    var day = dateObj.getDate();
				    var year = dateObj.getFullYear();

				    if (day.toString().length == 1) {
				        day = "0" + day;
				    }

				    if (month.toString().length == 1) {
				        month = "0" + month;
				    }

				    var newdate = day + "-" + month + "-" + year;

				    return newdate;
				}


				history.pushState(null, null, location.href);
			      window.onpopstate = function () {
			          history.go(1);
			      };
