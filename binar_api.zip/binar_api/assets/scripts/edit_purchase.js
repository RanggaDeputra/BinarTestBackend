				var checked_umroh = false;
				var checked_israel = false;
				var count_add_layanan = 1;
				var count_add_layanan_new = 1;
				var array_layanan = new Array();
				var array_layanan_new = new Array();

				$("#select_tour").change(function(){
				 	var val = $(this).val();
				 	getTour(val);				 	
				});

				$("#select_tour").val($('#tour_id').val()).trigger('change');

				function getTour(id){

				  var data = new FormData();
				    data.append('tour_id', id);
				    var url = window.location.origin + "/garnis_back_office/purchaseorder/get_single_tour";

				    $.ajax({
				      url: url,
				      type: 'POST',
				      data: data, 
				      processData: false,
				      contentType: false,
				      dataType: "json",
				      beforeSend: function(e) {
				        if(e && e.overrideMimeType) {
				          e.overrideMimeType("application/json;charset=UTF-8");
				        }
				      },
				      success: function(response){  
				        if(response.status == "success"){ 
				          $("#tour_name").val(response.tour.tour_name);
				          $("#tour_tgl").val(formatDateddmmyyyy(response.tour.tour_tgl_berangkat));
				          $("#tour_durasi").val(response.tour.tour_durasi);
				          $("#tour_biaya").val(response.tour.tour_biaya).trigger('paste');
				        }
				       },
				      error: function (xhr, ajaxOptions, thrownError) { 
				        alert(xhr.responseText);
				      }
				    });
				}


				$('#icheck_israel').on('ifChecked', function (event){
					$('#customer_last_israel').removeAttr('disabled');
					checked_israel = true;
					$(this).val('Y');
				});

				$('#icheck_israel').on('ifUnchecked', function (event){
					$('#customer_last_israel').val('');
					$('#customer_last_israel').attr('disabled','disabled');
					checked_israel = false;
					$(this).val('N');
				});

				$('#icheck_umroh').on('ifChecked', function (event){
					$('#customer_last_umroh').removeAttr('disabled');
					checked_umroh = true;
					$(this).val('Y');
				});

				$('#icheck_umroh').on('ifUnchecked', function (event){
				  	$('#customer_last_umroh').val('');
				  	$('#customer_last_umroh').attr('disabled','disabled');
				  	checked_umroh = false;
				  	$(this).val('N');
				});

				function formatDateddmmyyyy(date){
				    var dateObj = new Date(date);
				    var month = dateObj.getMonth() + 1; //months from 1-12
				    var day = dateObj.getDate();
				    var year = dateObj.getFullYear();

				    if (day.toString().length == 1) {
				        day = "0" + day;
				    }

				    if (month.toString().length == 1) {
				        month = "0" + month;
				    }

				    var newdate = day + "-" + month + "-" + year;

				    return newdate;
				}

				function setIdCustomer(id){
					$('#customer_id').val(id);
				}

				function getLayananCustomer(id){
					$('#customer_layanan').val(id);
					$('#layanan, #layanan_new').val("");
					array_layanan =  new Array();
					array_layanan_new =  new Array();
					count_add_layanan = 1;
					
					$('.container-add-layanan').empty();

					var data = new FormData();
				 	data.append('customer_id', $($("#customer_layanan")).val());
				 	data.append('po_id', $($("#po_id")).val());
				    var url = window.location.origin + "/garnis_back_office/purchaseorder/get_layanan_customer";

				    $.ajax({
				      url: url, 
				      type: 'POST', 
				      data: data,
				      processData: false,
				      contentType: false,
				      dataType: "json",
				      beforeSend: function(e) {
				        if(e && e.overrideMimeType) {
				          e.overrideMimeType("application/json;charset=UTF-8");
				        }
				      },
				      success: function(response){
				      	
				        	console.log(response);
				        if(response.status == "success"){ 
				           setViewLayanan(response.layanan);
				        }
				      },
				      error: function (xhr, ajaxOptions, thrownError) {
				        alert(xhr.responseText);
				      }
				    });
				}

				function setViewLayanan(layanan){
					for(var i = 0; i < layanan.length; i++){
						var lay = new Object(); 
						lay['custlay_id'] = layanan[i].custlay_id;
			            lay['custlay_customer_id'] = layanan[i].custlay_customer_id;
			            lay['custlay_layanan_id'] = layanan[i].custlay_layanan_id;
			            lay['custlay_status'] = layanan[i].custlay_status;

			            array_layanan.push(lay);

					    var content = '<div class="col-md-12" id="layanan'+count_add_layanan+'" style="margin-top: 10px;">'+
											'<div class="col-md-1 text-center">'+
												'<span>'+ count_add_layanan +'</span>'+
											'</div>'+
											'<div class="col-md-4">'+
												'<span>'+ layanan[i].layanan_name +'</span>'+
											'</div>'+
											'<div class="col-md-4">'+
												'<span>'+ layanan[i].layanan_biaya +'</span>'+
											'</div>'+
											'<div class="col-md-3 text-center">'+											
												'<select class="form-control select2" name="select_status_layanan" id="select_status_layanan'+ layanan[i].custlay_id +'" style="width: 100%" onchange="changeStatus('+layanan[i].custlay_id+');">'+
													'<option value="1">Active</option>'+
													'<option value="2">Cancel</option>'+
												'</select>'+
											'</div>'+
											'<div class="col-md-12 lines"></div>'+
										'</div>';

					    $(".container-add-layanan").append(content);

					    $("#select_status_layanan"+ layanan[i].custlay_id).val(layanan[i].custlay_status);

					    count_add_layanan++;
					}

					$(".select2").select2();

				    $("#layanan").val(JSON.stringify(array_layanan));
				}

				function changeStatus(id){
					for (var i = 0; i < array_layanan.length; i++) {
				        if (array_layanan[i]['custlay_id'] == id) {
				            array_layanan[i]['custlay_status'] = $("#select_status_layanan" + id).val();
				        }
				    }

				    $("#layanan").val(JSON.stringify(array_layanan));
				}

				$("#layanan_name").change(function() {
					var data = new FormData();
				 	data.append('layanan_id', $(this).val());
				    var url = window.location.origin + "/garnis_back_office/customers/get_layanan_harga";

				    $.ajax({
				      url: url, 
				      type: 'POST', 
				      data: data,
				      processData: false,
				      contentType: false,
				      dataType: "json",
				      beforeSend: function(e) {
				        if(e && e.overrideMimeType) {
				          e.overrideMimeType("application/json;charset=UTF-8");
				        }
				      },
				      success: function(response){
				        if(response.status == "success"){ 
				           $("#layanan_biaya").val(response.biaya);
				        }
				      },
				      error: function (xhr, ajaxOptions, thrownError) {
				        alert(xhr.responseText);
				      }
				    });
				});

				$("#layanan_name").trigger('change');

				function addLayanan(){
					var lay = new Object(); 
			        lay['custlay_customer_id'] = $("#customer_layanan").val();
			        lay['custlay_layanan_id'] = $("#layanan_name").val();

			        array_layanan_new.push(lay);

					var content = '<div class="col-md-12" id="layanan'+count_add_layanan+'" style="margin-top: 10px;">'+
											'<div class="col-md-1 text-center">'+
												'<span>'+ count_add_layanan +'</span>'+
											'</div>'+
											'<div class="col-md-4">'+
												'<span>'+ $("#layanan_name option:selected").text() +'</span>'+
											'</div>'+
											'<div class="col-md-4">'+
												'<span>'+ $("#layanan_biaya").val() +'</span>'+
											'</div>'+
											'<div class="col-md-3 text-center">'+											
												
											'</div>'+
											'<div class="col-md-12 lines"></div>'+
										'</div>';

					$(".container-add-layanan").append(content);

					count_add_layanan++;

				    $("#layanan_new").val(JSON.stringify(array_layanan_new));
				}

				function saveDetailCustomer(){
					if(!$("#customer_nik").val()){
				        $("#pesan-error").html('NIK wajib diisi!').show();
				        $("#customer_nik").focus();
				        return false;
				    }else if(!$("#customer_name").val()){
				        $("#pesan-error").html('Nama wajib diisi!').show();
				        $("#customer_name").focus();
				        return false;
				    }else if(!$("#customer_lahir").val()){
				        $("#pesan-error").html('Tempat lahir wajib diisi!').show();
				        $("#customer_lahir").focus();
				        return false;
				    }else if(!$("#customer_tgl_lahir").val()){
				        $("#pesan-error").html('Tanggal lahir wajib diisi!').show();
				        $("#customer_tgl_lahir").focus();
				        return false;
				    }else if(!$("#customer_kwn").val()){
				        $("#pesan-error").html('Kewarganegaraan wajib diisi!').show();
				        $("#customer_kwn").focus();
				        return false;
				    }else if(!$("#customer_pekerjaan").val()){
				        $("#pesan-error").html('Pekerjaan wajib diisi!').show();
				        $("#customer_pekerjaan").focus();
				        return false;
				    }else if(!$("#customer_ibu").val()){
				        $("#pesan-error").html('Nama ibu wajib diisi!').show();
				        $("#customer_ibu").focus();
				        return false;
				    }else if(!$("#customer_ayah").val()){
				        $("#pesan-error").html('Nama ayah wajib diisi!').show();
				        $("#customer_ayah").focus();
				        return false;
				    }else if(!$("#customer_kakek").val()){
				        $("#pesan-error").html('Nama kakek wajib diisi!').show();
				        $("#customer_kakek").focus();
				        return false;
				    }else if(!$("#customer_passport").val()){
				        $("#pesan-error").html('Nomor passport wajib diisi!').show();
				        $("#customer_passport").focus();
				        return false;
				    }else if(!$("#customer_passport_penerbit").val()){
				        $("#pesan-error").html('Negara penerbit wajib diisi!').show();
				        $("#customer_passport_penerbit").focus();
				        return false;
				    }else if(!$("#customer_passport_tgl").val()){
				        $("#pesan-error").html('Tanggal terbit passport wajib diisi!').show();
				        $("#customer_passport_tgl").focus();
				        return false;
				    }else if(!$("#customer_passport_tgl_akhir").val()){
				        $("#pesan-error").html('Tanggal masa berlaku passport wajib diisi!').show();
				        $("#customer_passport_tgl_akhir").focus();
				        return false;
				    }else if (checked_umroh) {
				        if(!$("#customer_last_umroh").val()){
				            $("#pesan-error").html('Tanggal terakhir umroh wajib diisi!').show();
				            $("#customer_last_umroh").focus();
				            return false;
				        }else{
					    	$("#pesan-error").hide();
					    	return true;
					    }
				    }else if (checked_israel) {
				        if(!$("#customer_last_israel").val()){
				            $("#pesan-error").html('Tanggal terakhir ke Israel wajib diisi!').show();
				            $("#customer_last_israel").focus();
				            return false;
				        }else{
					    	$("#pesan-error").hide();
					    	return true;
					    }
				    }else{
				    	$("#pesan-error").hide();
				    	return true;
				    }
				}