$('#icheck_jenis_participant').on('ifChecked', function (event){
	$('#customer_total').removeAttr('disabled');
  user_type = true;
	//$('#participant_tambahan').show();
});

$('#icheck_jenis_participant').on('ifUnchecked', function (event){
	$('#customer_total').attr('disabled', 'disabled');
  user_type = false;
	//$('#participant_tambahan').hide();
});

$( "#customer_tour" ).change(function() {
	var id = $(this).val();
	getSub(id);
});

$("#customer_tour").trigger('change');

function getSub(id){
	var data = new FormData();
	data.append('tour_id', id);
	var url = window.location.origin + "/garnis_back_office/customers/get_data_tour";

	$.ajax({
	    url: url, 
		type: 'POST', 
		data: data,
		processData: false,
		contentType: false,
		dataType: "json",
		beforeSend: function(e) {
		    if(e && e.overrideMimeType) {
			    e.overrideMimeType("application/json;charset=UTF-8");
			}
		},
		success: function(response){
			if(response.status == "success"){ 
           		$("#customer_sub_tour").val(response.sub_tour);
           		$("#customer_tgl_tour").val(response.tgl_berangkat);
           		$("#tour_kuota").val(response.quota);
			}
		},
		error: function (xhr, ajaxOptions, thrownError) {
			alert(xhr.responseText);
		}
	});
}

