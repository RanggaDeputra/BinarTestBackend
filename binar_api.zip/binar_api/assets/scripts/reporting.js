				var url = window.location.origin + "/garnis_back_office/reporting/get_tour_to_reporting";
				$.ajax({
				    url: url, 
				    type: 'GET', 
				    processData: false,
				    contentType: false,
				    dataType: "json",
				    beforeSend: function(e) {
				        if(e && e.overrideMimeType) {
				          e.overrideMimeType("application/json;charset=UTF-8");
				        }
				    },
				    success: function(response){
				        if(response.status == "success"){ 
							$('#calendar').fullCalendar({
								height: 550,
						      	defaultView: 'month',
						      	defaultDate: Date.now(),
						      	editable: true,
						      	eventLimit: true,
						      	events: response.tour,
						      	dayClick: function(date, jsEvent, view) {
							        if (jsEvent.target.classList.contains('fc-bgevent')) {
							            onEventClick(moment(date).format('YYYY-MM-DD'));
							        }
							    }
							    /*eventClick: function(calEvent, jsEvent, view) {
							      	//onEventClick(moment(calEvent.start).format('YYYY-MM-DD'));
							      	onEventClick(calEvent);
								},*/
								/*eventRender: function (event, element, view) { 
							        var dateString = event.start.format("YYYY-MM-DD");
							        
							        $(view.el[0]).find('.fc-day[data-date=' + dateString + ']').css('background-color', '#FAA732');
							    }*/
						       
						    });
				        }
				    },
				    error: function (xhr, ajaxOptions, thrownError) {
				        alert(xhr.responseText);
				    }
				});

				function onEventClick(date){
					var url = window.location.origin + "/garnis_back_office/reporting/detail/" + date;
					window.location.href = url;
					//alert(url);
				}