$("#tour_detail").change(function() {
    $(".container-add-trpts, .container-add-guide, .container-add-fnb, .container-add-hotel, .container-add-layanan").empty();
    getData($(this).val());
});

$("#tour_detail").trigger('change');

function getData(id){
    var data = new FormData();
    data.append('detail_id', id);
    data.append('customer_id', $("#customer_id").val());
    var url = window.location.origin + "/garnis_back_office/customers/get_data_itinerary";

    $.ajax({
      url: url,
      type: 'POST',
      data: data, 
      processData: false,
      contentType: false,
      dataType: "json",
      beforeSend: function(e) {
        if(e && e.overrideMimeType) {
          e.overrideMimeType("application/json;charset=UTF-8");
        }
      },
      success: function(response){
         if(response.status == "success"){ 
            $("#tour_kegiatan").val(response.detail.tourdetail_kegiatan);

            setViewTransport(response.transport);
            setViewGuide(response.guide);
            setViewFnB(response.fnb);
            setViewHotel(response.hotel);
            setViewLayanan(response.layanan);
         }
      },
      error: function (xhr, ajaxOptions, thrownError) { 
        alert(xhr.responseText);
      }
    });
}

        function setViewTransport(transport){
          for(var i = 0; i < transport.length; i++){
            var content = '<div class="col-md-12" id="trpts'+transport[i].transport_index+'" style="margin-top: 10px;">'+
                      '<div class="col-md-1 text-center">'+
                        '<span>'+ transport[i].transport_index +'</span>'+
                      '</div>'+
                      '<div class="col-md-4">'+
                        '<span>'+ transport[i].transport_merk +'</span>'+
                      '</div>'+
                      '<div class="col-md-4">'+
                        '<span>'+ transport[i].transport_tahun +'</span>'+
                      '</div>'+
                      '<div class="col-md-3 text-center">'+
                        '<span>'+ transport[i].transport_kapasitas +'</span>'+
                      '</div>'+
                      '<div class="col-md-12 lines"></div>'+
                    '</div>';

              $(".container-add-trpts").append(content);
          }
        }

        function setViewGuide(guide){
          for(var i = 0; i < guide.length; i++){
            var content = '<div class="col-md-12" id="guide'+guide[i].guide_index+'" style="margin-top: 10px;">'+
                      '<div class="col-md-1 text-center">'+
                        '<span>'+ guide[i].guide_index +'</span>'+
                      '</div>'+
                      '<div class="col-md-4">'+
                        '<span>'+ guide[i].guide_nama +'</span>'+
                      '</div>'+
                      '<div class="col-md-4">'+
                        '<span>'+ guide[i].guide_mulai +'</span>'+
                      '</div>'+
                      '<div class="col-md-3 text-center">'+
                        '<span>'+ guide[i].guide_selesai +'</span>'+
                      '</div>'+
                      '<div class="col-md-12 lines"></div>'+
                    '</div>';

              $(".container-add-guide").append(content);
          }
        }

        function setViewFnB(fnb){
          for(var i = 0; i < fnb.length; i++){
            var content = '<div class="col-md-12" id="fnb'+fnb[i].fnb_index+'" style="margin-top: 10px;">'+
                      '<div class="col-md-1 text-center">'+
                        '<span>'+ fnb[i].fnb_index +'</span>'+
                      '</div>'+
                      '<div class="col-md-4">'+
                        '<span>'+ fnb[i].fnb_food +'</span>'+
                      '</div>'+
                      '<div class="col-md-4">'+
                        '<span>'+ fnb[i].fnb_disiapkan +'</span>'+
                      '</div>'+
                      '<div class="col-md-3 text-center">'+
                        '<span>'+ fnb[i].fnb_jenis +'</span>'+
                      '</div>'+
                      '<div class="col-md-12 lines"></div>'+
                    '</div>';

              $(".container-add-fnb").append(content);
          }
        }

        function setViewHotel(hotel){
          for(var i = 0; i < hotel.length; i++){
            var content = '<div class="col-md-12" id="hotel'+hotel[i].tourhotel_index+'" style="margin-top: 10px;">'+
                      '<div class="col-md-1 text-center">'+
                        '<span>'+ hotel[i].tourhotel_index +'</span>'+
                      '</div>'+
                      '<div class="col-md-4">'+
                        '<span>'+ hotel[i].tourhotel_hotel_name +'</span>'+
                      '</div>'+
                      '<div class="col-md-4">'+
                        '<span>'+ hotel[i].tourhotel_jenis +'</span>'+
                      '</div>'+
                      '<div class="col-md-3 text-center">'+
                        '<span>'+ hotel[i].tourhotel_fasilitas +'</span>'+
                      '</div>'+
                      '<div class="col-md-12 lines"></div>'+
                    '</div>';

              $(".container-add-hotel").append(content);
          }
        }

        function setViewLayanan(layanan){
          var index =  1;
          for(var i = 0; i < layanan.length; i++){
            var content = '<div class="col-md-12" id="layanan'+layanan[i].layanan_index+'" style="margin-top: 10px;">'+
                    '<div class="col-md-1 text-center">'+
                      '<span>'+ index +'</span>'+
                    '</div>'+
                    '<div class="col-md-4">'+
                      '<span>'+ layanan[i].layanan_name +'</span>'+
                    '</div>'+
                    '<div class="col-md-4">'+
                      '<span>'+ layanan[i].layanan_lokasi +'</span>'+
                    '</div>'+
                    '<div class="col-md-3">'+
                      '<span>'+ layanan[i].layanan_jam +'</span>'+
                    '</div>'+
                  '</div>';

              $(".container-add-layanan").append(content);
              index++;
          }
        }