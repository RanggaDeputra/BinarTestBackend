				$("#alert-danger").hide();
				var checked_fullboard = false;
				var checked_city_tour = false;


				$('#icheck_fullboard').on('ifChecked', function (event){
					$('#tiket_penanganan, #tiket_akomodasi').attr('disabled', 'disabled');
					$("#tiket_fullboard").val(1);
				  	checked_fullboard = true;
				});

				$('#icheck_fullboard').on('ifUnchecked', function (event){
					$('#tiket_penanganan, #tiket_akomodasi').removeAttr('disabled');
					$("#tiket_fullboard").val(2);
				  	checked_fullboard = false;
				});

				$('#icheck_city_tour').on('ifChecked', function (event){
					$('#tiket_tour_biaya').removeAttr('disabled');
					$("#tiket_city_tour").val(1);
				  	checked_city_tour = true;
				});

				$('#icheck_city_tour').on('ifUnchecked', function (event){
					$('#tiket_tour_biaya').attr('disabled', 'disabled');
					$("#tiket_city_tour").val(2);
				  	checked_city_tour = false;
				});


				viewTicket($('#tiket_route_id').val());

				function save(){
					if(!$("#tiket_booking").val()){
				        $("#tiket_booking").focus();
				        return false;
				    }else if(!$("#tiket_maskapai").val()){
				        $("#tiket_maskapai").focus();
				        return false;
				    }else if(!$("#tiket_flight_no").val()){
				        $("#tiket_flight_no").focus();
				        return false;
				    }else if(!$("#tiket_pesawat").val()){
				        $("#tiket_pesawat").focus();
				        return false;
				    }else if(!$("#tiket_bandara_dept").val()){
				        $("#tiket_bandara_dept").focus();
				        return false;
				    }else if(!$("#tiket_tgl_dep").val()){
				        $("#tiket_tgl_dep").focus();
				        return false;
				    }else if(!$("#tiket_etd").val()){
				        $("#tiket_etd").focus();
				        return false;
				    }else if(!$("#tiket_bandara_arriv").val()){
				        $("#tiket_bandara_arriv").focus();
				        return false;
				    }else if(!$("#tiket_tgl_arriv").val()){
				        $("#tiket_tgl_arriv").focus();
				        return false;
				    }else if(!$("#tiket_eta").val()){
				        $("#tiket_eta").focus();
				        return false;
				    }
				}

				function saveTransit(){
					if(!$("#tiket_id").val()){
						$("#msg-danger").html('Gagal simpan data transit. Mohon isi data tiket terlebih dahulu!');
				        $("#alert-danger").show();
				        return false;
				    }else if(!$("#tiket_transit").val()){
						$("#msg-danger").html('Gagal simpan data transit. Mohon isi data transit terlebih dahulu!');
				        $("#alert-danger").show();
				        return false;
				    }
				}

				function viewTicket(id){
				    var data = new FormData();
				    data.append('troute_id', id);
				    var url = window.location.origin + "/garnis_back_office/ticketrequest/get_single_ticket";

				    $.ajax({
				      url: url, 
				      type: 'POST', 
				      data: data,
				      processData: false,
				      contentType: false,
				      dataType: "json",
				      beforeSend: function(e) {
				        if(e && e.overrideMimeType) {
				          e.overrideMimeType("application/json;charset=UTF-8");
				        }
				      },
				      success: function(response){
				        if(response.status == "success"){ 

				           $("#tiket_id").val(response.data.ttour_id);
				           $("#tiket_booking").val(response.data.ttour_code_book);
				           $("#tiket_maskapai").val(response.data.ttour_maskapai);
				           $("#tiket_flight_no").val(response.data.ttour_flight_number);
				           $("#tiket_pesawat").val(response.data.ttour_jenis_pesawat);
				           $("#tiket_bandara_dept").val(response.data.ttour_bandara_dep);
				           $("#tiket_tgl_dep").val(formatDateddmmyyyy(response.data.ttour_tgl_dep)).trigger('change');
				           $("#tiket_etd").val(response.data.ttour_etd).trigger('change');
				           $("#tiket_bandara_arriv").val(response.data.ttour_bandara_arriv);
				           $("#tiket_tgl_arriv").val(formatDateddmmyyyy(response.data.ttour_tgl_arriv)).trigger('change');
				           $("#tiket_eta").val(response.data.ttour_eta).trigger('change');

				           getTransit(response.data.ttour_id);
				        }
				      },
				      error: function (xhr, ajaxOptions, thrownError) {
				        alert(xhr.responseText);
				      },
				      async: false
				    });
				}

				function getTransit(id){
					var data = new FormData();
				    data.append('ttour_id', id);
				    data.append('ttour_origin', 'tiketing');
				    var url = window.location.origin + "/garnis_back_office/ticketrequest/get_transit";

				    $.ajax({
				      url: url, 
				      type: 'POST', 
				      data: data,
				      processData: false,
				      contentType: false,
				      success: function(response){
				      	$('#table-transit tbody').empty();
            			$('#table-transit tbody').html(response);
				        
				      }
				    });
				}

				var count_add_transit = 1;

				var array_transit = new Array();

				function addTransit(){
					if(!$("#transit_lokasi").val()){
				        $("#transit_lokasi").focus();
				        return false;
				    }else if(!$("#transit_lama").val()){
				        $("#transit_lama").focus();
				        return false;
				    }else{
				    	viewTransit();
				    }
				}

				function viewTransit(){
					var transit = new Object();
		            transit['ttransit_index'] = count_add_transit;
		            transit['ttransit_ttour_id'] = $("#tiket_id").val();
		            transit['ttransit_lokasi'] = $("#transit_lokasi").val();
		            transit['ttransit_waktu'] = $("#transit_lama").val();

		            array_transit.push(transit);

				    var content = '<div class="col-md-12" id="trpts'+count_add_transit+'" style="margin-top: 10px;">'+
										'<div class="col-md-1 text-center">'+
											'<span>'+ transit.ttransit_index +'</span>'+
										'</div>'+
										'<div class="col-md-6">'+
											'<span>'+ transit.ttransit_lokasi +'</span>'+
										'</div>'+
										'<div class="col-md-5 text-center">'+
											'<span>'+ transit.ttransit_waktu +'</span>'+
										'</div>'+
										'<div class="col-md-12 lines"></div>'+
									'</div>';

				    $(".container-add-transit").append(content);
				    count_add_transit++;

				    $("#transit_lokasi, #transit_lama").val('');
				    $("#tiket_transit").val(JSON.stringify(array_transit));
				}

				function hapusTransit(id){
					$("#transit_id").val(id);
				}

				function stpcTransit(id){
					$("#id").val(id);
					var data = new FormData();
				    data.append('transit_id', id);
				    var url = window.location.origin + "/garnis_back_office/ticketrequest/get_single_stpc";

				    $.ajax({
				      url: url, 
				      type: 'POST', 
				      data: data,
				      processData: false,
				      contentType: false,
				      dataType: "json",
				      beforeSend: function(e) {
				        if(e && e.overrideMimeType) {
				          e.overrideMimeType("application/json;charset=UTF-8");
				        }
				      },
				      success: function(response){
				        if(response.status == "success"){ 


				           	$("#tiket_stpc_biaya").val(response.data.tstpc_biaya);
				           	$("#tiket_stpc_hotel").val(response.data.tstpc_hotel);

				           if (response.data.tstpc_fullboard == 1) {
				              $("#icheck_fullboard").iCheck('check');
				              checked_fullboard = true;
				           }else{
				           	  $("#icheck_fullboard").iCheck('uncheck');
				           	  $("#tiket_penanganan").val(response.data.tstpc_fullboard_penanganan);
				              $("#tiket_akomodasi").val(response.data.tstpc_fullboard_akomodasi);
				              checked_fullboard = false;
				           }

				           if (response.data.tstpc_city_tour == 1) {
				              $("#tiket_tour_biaya").val(response.data.tstpc_city_tour_biaya);
				              $("#tiket_tour_biaya").removeAttr('disabled');
				              $("#icheck_city_tour").iCheck('check');
				              checked_stpc = true;
				           }				           
				        }
				      },
				      error: function (xhr, ajaxOptions, thrownError) {
				        alert(xhr.responseText);
				      }
				    });
				}

				$("#tiket_tgl_arriv").change(function(){
					var tgl_dep = $("#tiket_tgl_dep").val();
					if (dateDiff(tgl_dep, $(this).val()) < 0) {
						$("#msg-danger").html('Tgl arrival tidak boleh kurang dari tgl departure!');
				        $("#alert-danger").show();
				        $(this).focus();
					}else{
						$('#alert-danger').hide();
					}
				});

				function dateDiff(dt1, dt2){
				   	var a = moment(dt1,'DD-MM-YYYY');
					var b = moment(dt2,'DD-MM-YYYY');
					return diffDays = b.diff(a, 'days');
				}

				function formatDateddmmyyyy(date){
				    var dateObj = new Date(date);
				    var month = dateObj.getMonth() + 1; //months from 1-12
				    var day = dateObj.getDate();
				    var year = dateObj.getFullYear();

				    if (day.toString().length == 1) {
				        day = "0" + day;
				    }

				    if (month.toString().length == 1) {
				        month = "0" + month;
				    }

				    var newdate = day + "-" + month + "-" + year;

				    return newdate;
				}