<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MSessionLogin extends CI_Model {

	public function session_login(){
		$travel_id = $this->session->userdata('travelid');
		if (empty($travel_id)) {
			$this->session->sess_destroy();
			redirect('rest_update');
		}
  	}
}
